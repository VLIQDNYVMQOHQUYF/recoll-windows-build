<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh" sourcelanguage="en">
<context>
    <name>ActSearchDLG</name>
    <message>
        <source>Menu search</source>
        <translation>菜单搜索</translation>
    </message>
</context>
<context>
    <name>AdvSearch</name>
    <message>
        <source>All clauses</source>
        <translation>全部条件</translation>
    </message>
    <message>
        <source>Any clause</source>
        <translation>任意条件</translation>
    </message>
    <message>
        <source>texts</source>
        <translation>文本</translation>
    </message>
    <message>
        <source>spreadsheets</source>
        <translation>电子表格</translation>
    </message>
    <message>
        <source>presentations</source>
        <translation type="obsolete">演示文稿</translation>
    </message>
    <message>
        <source>media</source>
        <translation>多媒体文件</translation>
    </message>
    <message>
        <source>messages</source>
        <translation type="obsolete">邮件</translation>
    </message>
    <message>
        <source>other</source>
        <translation>其它</translation>
    </message>
    <message>
        <source>Bad multiplier suffix in size filter</source>
        <translation>文件尺寸过滤器的后缀单位不正确</translation>
    </message>
    <message>
        <source>text</source>
        <translation>文本文件</translation>
    </message>
    <message>
        <source>spreadsheet</source>
        <translation>电子表格</translation>
    </message>
    <message>
        <source>presentation</source>
        <translation>演示文档</translation>
    </message>
    <message>
        <source>message</source>
        <translation>邮件</translation>
    </message>
    <message>
        <source>Advanced Search</source>
        <translation>高级搜索</translation>
    </message>
    <message>
        <source>Load next stored search</source>
        <translation>加载下一个存储的搜索</translation>
    </message>
    <message>
        <source>Load previous stored search</source>
        <translation>加载先前存储的搜索</translation>
    </message>
</context>
<context>
    <name>AdvSearchBase</name>
    <message>
        <source>Advanced search</source>
        <translation>高端搜索</translation>
    </message>
    <message>
        <source>Search for &lt;br&gt;documents&lt;br&gt;satisfying:</source>
        <translation>搜索&lt;br&gt;满足以下条件&lt;br&gt;的文档：</translation>
    </message>
    <message>
        <source>Delete clause</source>
        <translation>删除条件</translation>
    </message>
    <message>
        <source>Add clause</source>
        <translation>添加条件</translation>
    </message>
    <message>
        <source>Restrict file types</source>
        <translation>限定文件类型</translation>
    </message>
    <message>
        <source>Check this to enable filtering on file types</source>
        <translation>选中这个，以便针对文件类型进行过滤</translation>
    </message>
    <message>
        <source>By categories</source>
        <translation>按大类来过滤</translation>
    </message>
    <message>
        <source>Check this to use file categories instead of raw mime types</source>
        <translation>选中这个，以便使用较大的分类，而不使用具体的文件类型</translation>
    </message>
    <message>
        <source>Save as default</source>
        <translation>保存为默认值</translation>
    </message>
    <message>
        <source>Searched file types</source>
        <translation>将被搜索的文件类型</translation>
    </message>
    <message>
        <source>All ----&gt;</source>
        <translation>移动全部→</translation>
    </message>
    <message>
        <source>Sel -----&gt;</source>
        <translation>移动选中项→</translation>
    </message>
    <message>
        <source>&lt;----- Sel</source>
        <translation>←移动选中项</translation>
    </message>
    <message>
        <source>&lt;----- All</source>
        <translation>←移动全部</translation>
    </message>
    <message>
        <source>Ignored file types</source>
        <translation>要忽略的文件类型</translation>
    </message>
    <message>
        <source>Enter top directory for search</source>
        <translation>输入要搜索的最上层目录</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <source>Restrict results to files in subtree:</source>
        <translation>将结果中的文件限定在此子目录树中：</translation>
    </message>
    <message>
        <source>Start Search</source>
        <translation>开始搜索</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <source>All non empty fields on the right will be combined with AND (&quot;All clauses&quot; choice) or OR (&quot;Any clause&quot; choice) conjunctions. &lt;br&gt;&quot;Any&quot; &quot;All&quot; and &quot;None&quot; field types can accept a mix of simple words, and phrases enclosed in double quotes.&lt;br&gt;Fields with no data are ignored.</source>
        <translation>右边的所有非空字段都会按照逻辑与（“全部条件”选项）或逻辑或（“任意条件”选项）来组合。&lt;br&gt;“任意”“全部”和“无”三种字段类型都接受输入简单词语和双引号引用的词组的组合。&lt;br&gt;空的输入框会被忽略。</translation>
    </message>
    <message>
        <source>Invert</source>
        <translation>反转过滤条件</translation>
    </message>
    <message>
        <source>Minimum size. You can use k/K,m/M,g/G as multipliers</source>
        <translation>最小尺寸。你可使用k/K、m/M、g/G作为单位</translation>
    </message>
    <message>
        <source>Min. Size</source>
        <translation>最小尺寸</translation>
    </message>
    <message>
        <source>Maximum size. You can use k/K,m/M,g/G as multipliers</source>
        <translation>最大尺寸。你可使用k/K、m/M、g/G作为单位</translation>
    </message>
    <message>
        <source>Max. Size</source>
        <translation>最大尺寸</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>过滤</translation>
    </message>
    <message>
        <source>From</source>
        <translation>从</translation>
    </message>
    <message>
        <source>To</source>
        <translation>到</translation>
    </message>
    <message>
        <source>Check this to enable filtering on dates</source>
        <translation>选中这个，以便针对日期进行过滤</translation>
    </message>
    <message>
        <source>Filter dates</source>
        <translation>过滤日期</translation>
    </message>
    <message>
        <source>Filter birth dates</source>
        <translation>过滤创建日期</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>查找</translation>
    </message>
    <message>
        <source>Check this to enable filtering on sizes</source>
        <translation>选中这个，以便针对文件尺寸进行过滤</translation>
    </message>
    <message>
        <source>Filter sizes</source>
        <translation>过滤尺寸</translation>
    </message>
</context>
<context>
    <name>ConfIndexW</name>
    <message>
        <source>Can&apos;t write configuration file</source>
        <translation>无法写入配置文件</translation>
    </message>
    <message>
        <source>Global parameters</source>
        <translation>全局参数</translation>
    </message>
    <message>
        <source>Local parameters</source>
        <translation>局部参数</translation>
    </message>
    <message>
        <source>Search parameters</source>
        <translation>搜索参数</translation>
    </message>
    <message>
        <source>Top directories</source>
        <translation type="obsolete">顶级目录</translation>
    </message>
    <message>
        <source>The list of directories where recursive indexing starts. Default: your home.</source>
        <translation type="obsolete">索引从这个列表中的目录开始，递归地进行。默认：你的家目录。</translation>
    </message>
    <message>
        <source>Skipped paths</source>
        <translation>略过的路径</translation>
    </message>
    <message>
        <source>These are pathnames of directories which indexing will not enter.&lt;br&gt;Path elements may contain wildcards. The entries must match the paths seen by the indexer (e.g.: if topdirs includes &apos;/home/me&apos; and &apos;/home&apos; is actually a link to &apos;/usr/home&apos;, a correct skippedPath entry would be &apos;/home/me/tmp*&apos;, not &apos;/usr/home/me/tmp*&apos;)</source>
        <translation>这些是索引不会进入的目录路径。&lt;br&gt;路径元素可能包含通配符。条目必须与索引器看到的路径匹配（例如：如果topdirs包括&apos;/home/me&apos;，而&apos;/home&apos;实际上是指向&apos;/usr/home&apos;的链接，则正确的skippedPath条目应为&apos;/home/me/tmp*&apos;，而不是&apos;/usr/home/me/tmp*&apos;）</translation>
    </message>
    <message>
        <source>Stemming languages</source>
        <translation>词根语言</translation>
    </message>
    <message>
        <source>The languages for which stemming expansion&lt;br&gt;dictionaries will be built.</source>
        <translation type="obsolete">将会针对这些语言&lt;br&gt;构造词根扩展词典。</translation>
    </message>
    <message>
        <source>Log file name</source>
        <translation>记录文件名</translation>
    </message>
    <message>
        <source>The file where the messages will be written.&lt;br&gt;Use &apos;stderr&apos; for terminal output</source>
        <translation>程序输出的消息会被保存到这个文件。&lt;br&gt;使用&apos;stderr&apos;以表示将消息输出到终端</translation>
    </message>
    <message>
        <source>Log verbosity level</source>
        <translation>记录的话痨级别</translation>
    </message>
    <message>
        <source>This value adjusts the amount of messages,&lt;br&gt;from only errors to a lot of debugging data.</source>
        <translation>这个值调整的是输出的消息的数量，&lt;br&gt;其级别从仅输出报错信息到输出一大堆调试信息。</translation>
    </message>
    <message>
        <source>Index flush megabytes interval</source>
        <translation>刷新索引的间隔，兆字节</translation>
    </message>
    <message>
        <source>This value adjust the amount of data which is indexed between flushes to disk.&lt;br&gt;This helps control the indexer memory usage. Default 10MB </source>
        <translation>这个值调整的是，当积累咯多少索引数据时，才将数据刷新到硬盘上去。&lt;br&gt;用来控制索引进程的内存占用情况。默认为10MB</translation>
    </message>
    <message>
        <source>This is the percentage of disk usage - total disk usage, not index size - at which indexing will fail and stop.&lt;br&gt;The default value of 0 removes any limit.</source>
        <translation>这是磁盘使用率的百分比 - 总磁盘使用率，而不是索引大小 - 在此百分比下，索引将失败并停止。&lt;br&gt;默认值为0，表示没有任何限制。</translation>
    </message>
    <message>
        <source>No aspell usage</source>
        <translation>不使用aspell</translation>
    </message>
    <message>
        <source>Disables use of aspell to generate spelling approximation in the term explorer tool.&lt;br&gt; Useful if aspell is absent or does not work. </source>
        <translation>禁止在词语探索器中使用aspell来生成拼写相近的词语。&lt;br&gt;在没有安装aspell或者它工作不正常时使用这个选项。</translation>
    </message>
    <message>
        <source>Aspell language</source>
        <translation>Aspell语言</translation>
    </message>
    <message>
        <source>Database directory name</source>
        <translation type="vanished">数据库目录名</translation>
    </message>
    <message>
        <source>The name for a directory where to store the index&lt;br&gt;A non-absolute path is taken relative to the configuration directory. The default is &apos;xapiandb&apos;.</source>
        <translation type="vanished">用于存储索引的目录名称
非绝对路径将相对于配置目录进行处理。默认为&apos;xapiandb&apos;。</translation>
    </message>
    <message>
        <source>Unac exceptions</source>
        <translation>Unac exceptions
Unac异常</translation>
    </message>
    <message>
        <source>&lt;p&gt;These are exceptions to the unac mechanism which, by default, removes all diacritics, and performs canonic decomposition. You can override unaccenting for some characters, depending on your language, and specify additional decompositions, e.g. for ligatures. In each space-separated entry, the first character is the source one, and the rest is the translation.</source>
        <translation>这些是对unac机制的例外情况，默认情况下会删除所有变音符号，并执行规范分解。您可以根据您的语言覆盖某些字符的去重音，并指定额外的分解，例如连字。在每个以空格分隔的条目中，第一个字符是源字符，其余是翻译。</translation>
    </message>
    <message>
        <source>Enables indexing Firefox visited pages.&lt;br&gt;(you need also install the Firefox Recoll plugin)</source>
        <translation>启用索引Firefox访问过的页面。&lt;br&gt;（您还需要安装Firefox Recoll插件）</translation>
    </message>
    <message>
        <source>Web page store directory name</source>
        <translation>网页储存目录名</translation>
    </message>
    <message>
        <source>The name for a directory where to store the copies of visited web pages.&lt;br&gt;A non-absolute path is taken relative to the configuration directory.</source>
        <translation>用来储存复制过来的已访问网页的目录名。&lt;br&gt;如果使用相对路径，则会相对于配置目录的路径进行处理。</translation>
    </message>
    <message>
        <source>Max. size for the web store (MB)</source>
        <translation>网页存储的最大尺寸（MB）</translation>
    </message>
    <message>
        <source>Entries will be recycled once the size is reached.&lt;br&gt;Only increasing the size really makes sense because reducing the value will not truncate an existing file (only waste space at the end).</source>
        <translation>一旦达到大小限制，条目将被回收利用。只有增加大小才有意义，因为减小值不会截断现有文件（只会在末尾浪费空间）。</translation>
    </message>
    <message>
        <source>Automatic diacritics sensitivity</source>
        <translation>自动重音符号敏感度</translation>
    </message>
    <message>
        <source>&lt;p&gt;Automatically trigger diacritics sensitivity if the search term has accented characters (not in unac_except_trans). Else you need to use the query language and the &lt;i&gt;D&lt;/i&gt; modifier to specify diacritics sensitivity.</source>
        <translation>如果搜索词中包含重音字符（不在unac_except_trans中），则自动触发重音敏感性。否则，您需要使用查询语言和&lt;i&gt;D&lt;/i&gt;修饰符来指定重音敏感性。</translation>
    </message>
    <message>
        <source>Automatic character case sensitivity</source>
        <translation>自动字符大小写敏感</translation>
    </message>
    <message>
        <source>&lt;p&gt;Automatically trigger character case sensitivity if the entry has upper-case characters in any but the first position. Else you need to use the query language and the &lt;i&gt;C&lt;/i&gt; modifier to specify character-case sensitivity.</source>
        <translation>&lt;p&gt;如果输入中除了第一个位置以外还有大写字符，则自动触发字符大小写敏感性。否则，您需要使用查询语言和&lt;i&gt;C&lt;/i&gt;修饰符来指定字符大小写敏感性。</translation>
    </message>
    <message>
        <source>Maximum term expansion count</source>
        <translation>最大术语扩展计数</translation>
    </message>
    <message>
        <source>&lt;p&gt;Maximum expansion count for a single term (e.g.: when using wildcards). The default of 10 000 is reasonable and will avoid queries that appear frozen while the engine is walking the term list.</source>
        <translation>单个术语的最大扩展计数（例如：使用通配符时）。默认值为10,000，这是合理的，可以避免在引擎遍历术语列表时出现查询似乎冻结的情况。</translation>
    </message>
    <message>
        <source>Maximum Xapian clauses count</source>
        <translation>最大Xapian子句数量</translation>
    </message>
    <message>
        <source>&lt;p&gt;Maximum number of elementary clauses we add to a single Xapian query. In some cases, the result of term expansion can be multiplicative, and we want to avoid using excessive memory. The default of 100 000 should be both high enough in most cases and compatible with current typical hardware configurations.</source>
        <translation>&lt;p&gt;我们添加到单个Xapian查询的基本子句的最大数量。在某些情况下，术语扩展的结果可能是乘法的，我们希望避免使用过多的内存。默认值为100,000，在大多数情况下应该足够高，并且与当前典型的硬件配置兼容。</translation>
    </message>
    <message>
        <source>The languages for which stemming expansion dictionaries will be built.&lt;br&gt;See the Xapian stemmer documentation for possible values. E.g. english, french, german...</source>
        <translation>将构建词干扩展词典的语言。&lt;br&gt;请参阅Xapian词干处理器文档以获取可能的值。例如：英语，法语，德语...</translation>
    </message>
    <message>
        <source>The language for the aspell dictionary. The values are are 2-letter language codes, e.g. &apos;en&apos;, &apos;fr&apos; ...&lt;br&gt;If this value is not set, the NLS environment will be used to compute it, which usually works. To get an idea of what is installed on your system, type &apos;aspell config&apos; and look for .dat files inside the &apos;data-dir&apos; directory.</source>
        <translation>拼写词典的语言。值是两个字母的语言代码，例如 &apos;en&apos;，&apos;fr&apos; ...&lt;br&gt;如果未设置此值，则将使用NLS环境来计算它，通常会起作用。要了解系统上安装了什么，请键入 &apos;aspell config&apos; 并查找 &apos;data-dir&apos; 目录中的 .dat 文件。</translation>
    </message>
    <message>
        <source>Indexer log file name</source>
        <translation>索引器日志文件名称</translation>
    </message>
    <message>
        <source>If empty, the above log file name value will be used. It may useful to have a separate log for diagnostic purposes because the common log will be erased when&lt;br&gt;the GUI starts up.</source>
        <translation>如果为空，则将使用上述日志文件名值。为了诊断目的，可能有一个单独的日志文件是有用的，因为当GUI启动时，常规日志将被擦除。</translation>
    </message>
    <message>
        <source>Web history</source>
        <translation>网络历史</translation>
    </message>
    <message>
        <source>Process the Web history queue</source>
        <translation>处理网络历史记录队列</translation>
    </message>
    <message>
        <source>(by default, aspell suggests mispellings when a query has no results).</source>
        <translation type="obsolete">（默认情况下，当查询没有结果时，拼写检查会建议拼写错误）。</translation>
    </message>
    <message>
        <source>Page recycle interval</source>
        <translation>页面回收间隔</translation>
    </message>
    <message>
        <source>&lt;p&gt;By default, only one instance of an URL is kept in the cache. This can be changed by setting this to a value determining at what frequency we keep multiple instances (&apos;day&apos;, &apos;week&apos;, &apos;month&apos;, &apos;year&apos;). Note that increasing the interval will not erase existing entries.</source>
        <translation>默认情况下，缓存中只保留一个URL实例。可以通过将其设置为确定我们保留多个实例的频率的值来更改这一点（&apos;day&apos;，&apos;week&apos;，&apos;month&apos;，&apos;year&apos;）。请注意，增加间隔不会删除现有条目。</translation>
    </message>
    <message>
        <source>Note: old pages will be erased to make space for new ones when the maximum size is reached. Current size: %1</source>
        <translation>注意：当达到最大大小时，旧页面将被删除以为新页面腾出空间。当前大小：%1</translation>
    </message>
    <message>
        <source>Start folders</source>
        <translation>开始文件夹</translation>
    </message>
    <message>
        <source>The list of folders/directories to be indexed. Sub-folders will be recursively processed. Default: your home.</source>
        <translation type="obsolete">要被索引的文件夹/目录列表。子文件夹将被递归处理。默认值：您的主目录。</translation>
    </message>
    <message>
        <source>Disk full threshold percentage at which we stop indexing&lt;br&gt;(E.g. 90 to stop at 90% full, 0 or 100 means no limit)</source>
        <translation>磁盘满时停止索引的阈值百分比（例如，90表示在90%满时停止，0或100表示没有限制）</translation>
    </message>
    <message>
        <source>Suspend the real time indexer when running on battery</source>
        <translation>在电池模式下运行时暂停实时索引器</translation>
    </message>
    <message>
        <source>The indexer will wait for a return on AC and reexec itself when it happens</source>
        <translation>索引器将等待AC返回，并在发生时重新执行自身。</translation>
    </message>
    <message>
        <source>Browser add-on download folder</source>
        <translation>浏览器插件下载文件夹</translation>
    </message>
    <message>
        <source>Only set this if you set the &quot;Downloads subdirectory&quot; parameter in the Web browser add-on settings. &lt;br&gt;In this case, it should be the full path to the directory (e.g. /home/[me]/Downloads/my-subdir)</source>
        <translation>只有在Web浏览器插件设置中设置了“下载子目录”参数时才设置此选项。&lt;br&gt;在这种情况下，它应该是目录的完整路径（例如/home/[me]/Downloads/my-subdir）。</translation>
    </message>
    <message>
        <source>Store some GUI parameters locally to the index</source>
        <translation>将一些GUI参数存储到本地索引中。</translation>
    </message>
    <message>
        <source>&lt;p&gt;GUI settings are normally stored in a global file, valid for all indexes. Setting this parameter will make some settings, such as the result table setup, specific to the index</source>
        <translation>&lt;p&gt;GUI设置通常存储在一个全局文件中，适用于所有索引。设置此参数将使一些设置，如结果表设置，特定于索引。</translation>
    </message>
    <message>
        <source>The list of folders/directories to be indexed, recursively with their sub-folders.&lt;br&gt;The &apos;~&apos; character expands to your home directory, which is the default initial value.</source>
        <translation type="vanished">要递归地索引的文件夹/目录列表及其子文件夹。&lt;br&gt;字符“~”会扩展为您的主目录，这是默认初始值。</translation>
    </message>
    <message>
        <source> (by default, aspell suggests mispellings when a query has no results).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The name or path for a directory where to store the index&lt;br&gt;A non-absolute path is taken relative to the configuration directory. The default is &apos;xapiandb&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The list of folders/directories to be indexed, recursively with their sub-folders.&lt;br&gt;%USERPROFILE% or the &apos;~&apos; character expand to your user profile, which is the default The &apos;~&apos; character expands to your home directory, which is the default initial value.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfSubPanelW</name>
    <message>
        <source>Only mime types</source>
        <translation>只有 MIME 类型</translation>
    </message>
    <message>
        <source>An exclusive list of indexed mime types.&lt;br&gt;Nothing else will be indexed. Normally empty and inactive</source>
        <translation>一个专门列出索引的MIME类型的列表。&lt;br&gt;不会索引其他任何内容。通常为空且不活动。</translation>
    </message>
    <message>
        <source>Exclude mime types</source>
        <translation>排除 MIME 类型</translation>
    </message>
    <message>
        <source>Mime types not to be indexed</source>
        <translation>不要索引的MIME类型</translation>
    </message>
    <message>
        <source>Max. compressed file size (KB)</source>
        <translation>压缩文件最大尺寸（KB）</translation>
    </message>
    <message>
        <source>This value sets a threshold beyond which compressedfiles will not be processed. Set to -1 for no limit, to 0 for no decompression ever.</source>
        <translation>尺寸大于这个值的压缩文件不会被处理。设置成-1以表示不加任何限制，设置成0以表示根本不处理压缩文件。</translation>
    </message>
    <message>
        <source>Max. text file size (MB)</source>
        <translation>文本文件最大尺寸（MB）</translation>
    </message>
    <message>
        <source>This value sets a threshold beyond which text files will not be processed. Set to -1 for no limit. 
This is for excluding monster log files from the index.</source>
        <translation>尺寸大于这个值的文本文件不会被处理。设置成-1以表示不加限制。
其作用是从索引中排除巨型的记录文件。</translation>
    </message>
    <message>
        <source>Text file page size (KB)</source>
        <translation>文本文件单页尺寸（KB）</translation>
    </message>
    <message>
        <source>If this value is set (not equal to -1), text files will be split in chunks of this size for indexing.
This will help searching very big text  files (ie: log files).</source>
        <translation>如果设置咯这个值（不等于-1），则文本文件会被分割成这么大的块，并且进行索引。
这是用来搜索大型文本文件的（例如记录文件）。</translation>
    </message>
    <message>
        <source>Max. filter exec. time (s)</source>
        <translation>最大过滤器执行时间（秒）</translation>
    </message>
    <message>
        <source>External filters working longer than this will be aborted. This is for the rare case (ie: postscript) where a document could cause a filter to loop. Set to -1 for no limit.
</source>
        <translation>外部过滤器工作时间超过此时间将被中止。这是为了罕见情况（例如：后置脚本），其中文档可能导致过滤器循环。设置为-1表示没有限制。</translation>
    </message>
    <message>
        <source>Global</source>
        <translation>全局</translation>
    </message>
</context>
<context>
    <name>ConfigSwitchDLG</name>
    <message>
        <source>Switch to other configuration</source>
        <translation type="vanished">切换到其他配置</translation>
    </message>
    <message>
        <source>Dialog</source>
        <translation type="unfinished">对话框</translation>
    </message>
</context>
<context>
    <name>ConfigSwitchW</name>
    <message>
        <source>Choose other</source>
        <translation>选择其他</translation>
    </message>
    <message>
        <source>Choose configuration directory</source>
        <translation>选择配置目录</translation>
    </message>
</context>
<context>
    <name>CronToolW</name>
    <message>
        <source>Cron Dialog</source>
        <translation>计划任务对话框</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Recoll&lt;/span&gt; batch indexing schedule (cron) &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Each field can contain a wildcard (*), a single numeric value, comma-separated lists (1,3,5) and ranges (1-7). More generally, the fields will be used &lt;span style=&quot; font-style:italic;&quot;&gt;as is&lt;/span&gt; inside the crontab file, and the full crontab syntax can be used, see crontab(5).&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;For example, entering &lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;*&lt;/span&gt; in &lt;span style=&quot; font-style:italic;&quot;&gt;Days, &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;12,19&lt;/span&gt; in &lt;span style=&quot; font-style:italic;&quot;&gt;Hours&lt;/span&gt; and &lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;15&lt;/span&gt; in &lt;span style=&quot; font-style:italic;&quot;&gt;Minutes&lt;/span&gt; would start recollindex every day at 12:15 AM and 7:15 PM&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A schedule with very frequent activations is probably less efficient than real time indexing.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;
&lt;!DOCTYPE html PUBLIC &quot;-//W3C//DTD XHTML 1.1 plus MathML 2.0//EN&quot; &quot;http://www.w3.org/Math/DTD/mathml2/xhtml-math11-f.dtd&quot;&gt;
&lt;html xmlns=&quot;http://www.w3.org/1999/xhtml&quot;&gt;&lt;!--This file was converted to xhtml by OpenOffice.org - see http://xml.openoffice.org/odf2xhtml for more info.--&gt;&lt;head profile=&quot;http://dublincore.org/documents/dcmi-terms/&quot;&gt;&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;application/xhtml+xml; charset=utf-8&quot;/&gt;&lt;title xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; ns_1:lang=&quot;en-US&quot;&gt;- no title specified&lt;/title&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.title&quot; content=&quot;&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;meta name=&quot;DCTERMS.language&quot; content=&quot;en-US&quot; scheme=&quot;DCTERMS.RFC4646&quot;/&gt;&lt;meta name=&quot;DCTERMS.source&quot; content=&quot;http://xml.openoffice.org/odf2xhtml&quot;/&gt;&lt;meta name=&quot;DCTERMS.issued&quot; content=&quot;2012-03-22T19:47:37&quot; scheme=&quot;DCTERMS.W3CDTF&quot;/&gt;&lt;meta name=&quot;DCTERMS.modified&quot; content=&quot;2012-03-22T19:56:53&quot; scheme=&quot;DCTERMS.W3CDTF&quot;/&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.provenance&quot; content=&quot;&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.subject&quot; content=&quot;,&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;link rel=&quot;schema.DC&quot; href=&quot;http://purl.org/dc/elements/1.1/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCTERMS&quot; href=&quot;http://purl.org/dc/terms/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCTYPE&quot; href=&quot;http://purl.org/dc/dcmitype/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCAM&quot; href=&quot;http://purl.org/dc/dcam/&quot; hreflang=&quot;en&quot;/&gt;&lt;style type=&quot;text/css&quot;&gt;
	@page {  }
	table { border-collapse:collapse; border-spacing:0; empty-cells:show }
	td, th { vertical-align:top; font-size:12pt;}
	h1, h2, h3, h4, h5, h6 { clear:both }
	ol, ul { margin:0; padding:0;}
	li { list-style: none; margin:0; padding:0;}
	&lt;!-- &quot;li span.odfLiEnd&quot; - IE 7 issue--&gt;
	li span. { clear: both; line-height:0; width:0; height:0; margin:0; padding:0; }
	span.footnodeNumber { padding-right:1em; }
	span.annotation_style_by_filter { font-size:95%; font-family:Arial; background-color:#fff000;  margin:0; border:0; padding:0;  }
	* { margin:0;}
	.P1 { font-size:12pt; margin-bottom:0cm; margin-top:0cm; font-family:Nimbus Roman No9 L; writing-mode:page; margin-left:0cm; margin-right:0cm; text-indent:0cm; }
	.T1 { font-weight:bold; }
	.T3 { font-style:italic; }
	.T4 { font-family:Courier New,courier; }
	&lt;!-- ODF styles with no properties representable as CSS --&gt;
	{ }
	&lt;/style&gt;&lt;/head&gt;&lt;body dir=&quot;ltr&quot; style=&quot;max-width:21.001cm;margin-top:2cm; margin-bottom:2cm; margin-left:2cm; margin-right:2cm; writing-mode:lr-tb; &quot;&gt;&lt;p class=&quot;P1&quot;&gt;&lt;span class=&quot;T1&quot;&gt;Recoll&lt;/span&gt; 批量索引计划任务(cron) &lt;/p&gt;&lt;p class=&quot;P1&quot;&gt;每个字段都可以包括一个通配符(*)、单个数字值、逗号分隔的列表(1,3,5)和范围(1-7)。更准确地说，这些字段会被&lt;span class=&quot;T3&quot;&gt;按原样&lt;/span&gt;输出到crontab 文件中，因此这里可以使用crontab 的所有语法，参考crontab(5)。&lt;/p&gt;&lt;p class=&quot;P1&quot;&gt;&lt;br/&gt;例如，在&lt;span class=&quot;T3&quot;&gt;日期&lt;/span&gt;中输入&lt;span class=&quot;T4&quot;&gt;*&lt;/span&gt;，&lt;span class=&quot;T3&quot;&gt;小时&lt;/span&gt;中输入&lt;span class=&quot;T4&quot;&gt;12,19&lt;/span&gt;，&lt;span class=&quot;T3&quot;&gt;分钟&lt;/span&gt;中输入&lt;span class=&quot;T4&quot;&gt;15 &lt;/span&gt;的话，会在每天的12:15 AM 和7:15 PM启动recollindex。&lt;/p&gt;&lt;p class=&quot;P1&quot;&gt;一个频繁执行的计划任务，其性能可能比不上实时索引。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</translation>
    </message>
    <message>
        <source>Days of week (* or 0-7, 0 or 7 is Sunday)</source>
        <translation>星期日(*或0-7，0或7是指星期天)</translation>
    </message>
    <message>
        <source>Hours (* or 0-23)</source>
        <translation>小时(*或0-23)</translation>
    </message>
    <message>
        <source>Minutes (0-59)</source>
        <translation>分钟(0-59)</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Click &lt;span style=&quot; font-style:italic;&quot;&gt;Disable&lt;/span&gt; to stop automatic batch indexing, &lt;span style=&quot; font-style:italic;&quot;&gt;Enable&lt;/span&gt; to activate it, &lt;span style=&quot; font-style:italic;&quot;&gt;Cancel&lt;/span&gt; to change nothing.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;
&lt;!DOCTYPE html PUBLIC &quot;-//W3C//DTD XHTML 1.1 plus MathML 2.0//EN&quot; &quot;http://www.w3.org/Math/DTD/mathml2/xhtml-math11-f.dtd&quot;&gt;
&lt;html xmlns=&quot;http://www.w3.org/1999/xhtml&quot;&gt;&lt;!--This file was converted to xhtml by OpenOffice.org - see http://xml.openoffice.org/odf2xhtml for more info.--&gt;&lt;head profile=&quot;http://dublincore.org/documents/dcmi-terms/&quot;&gt;&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;application/xhtml+xml; charset=utf-8&quot;/&gt;&lt;title xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; ns_1:lang=&quot;en-US&quot;&gt;- no title specified&lt;/title&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.title&quot; content=&quot;&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;meta name=&quot;DCTERMS.language&quot; content=&quot;en-US&quot; scheme=&quot;DCTERMS.RFC4646&quot;/&gt;&lt;meta name=&quot;DCTERMS.source&quot; content=&quot;http://xml.openoffice.org/odf2xhtml&quot;/&gt;&lt;meta name=&quot;DCTERMS.issued&quot; content=&quot;2012-03-22T20:08:00&quot; scheme=&quot;DCTERMS.W3CDTF&quot;/&gt;&lt;meta name=&quot;DCTERMS.modified&quot; content=&quot;2012-03-22T20:11:47&quot; scheme=&quot;DCTERMS.W3CDTF&quot;/&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.provenance&quot; content=&quot;&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.subject&quot; content=&quot;,&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;link rel=&quot;schema.DC&quot; href=&quot;http://purl.org/dc/elements/1.1/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCTERMS&quot; href=&quot;http://purl.org/dc/terms/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCTYPE&quot; href=&quot;http://purl.org/dc/dcmitype/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCAM&quot; href=&quot;http://purl.org/dc/dcam/&quot; hreflang=&quot;en&quot;/&gt;&lt;style type=&quot;text/css&quot;&gt;
	@page {  }
	table { border-collapse:collapse; border-spacing:0; empty-cells:show }
	td, th { vertical-align:top; font-size:12pt;}
	h1, h2, h3, h4, h5, h6 { clear:both }
	ol, ul { margin:0; padding:0;}
	li { list-style: none; margin:0; padding:0;}
	&lt;!-- &quot;li span.odfLiEnd&quot; - IE 7 issue--&gt;
	li span. { clear: both; line-height:0; width:0; height:0; margin:0; padding:0; }
	span.footnodeNumber { padding-right:1em; }
	span.annotation_style_by_filter { font-size:95%; font-family:Arial; background-color:#fff000;  margin:0; border:0; padding:0;  }
	* { margin:0;}
	.P1 { font-size:12pt; margin-bottom:0cm; margin-top:0cm; font-family:Nimbus Roman No9 L; writing-mode:page; margin-left:0cm; margin-right:0cm; text-indent:0cm; }
	.T2 { font-style:italic; }
	&lt;!-- ODF styles with no properties representable as CSS --&gt;
	{ }
	&lt;/style&gt;&lt;/head&gt;&lt;body dir=&quot;ltr&quot; style=&quot;max-width:21.001cm;margin-top:2cm; margin-bottom:2cm; margin-left:2cm; margin-right:2cm; writing-mode:lr-tb; &quot;&gt;&lt;p class=&quot;P1&quot;&gt;点击&lt;span class=&quot;T2&quot;&gt;禁用&lt;/span&gt;以停止进行自动化的批量索引，点击&lt;span class=&quot;T2&quot;&gt;启用&lt;/span&gt;以启用此功能，点击&lt;span class=&quot;T2&quot;&gt;取消&lt;/span&gt;则不改变任何东西。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation>启用</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>禁用</translation>
    </message>
    <message>
        <source>It seems that manually edited entries exist for recollindex, cannot edit crontab</source>
        <translation>看起来已经有手动编辑过的recollindex条目了，因此无法编辑crontab</translation>
    </message>
    <message>
        <source>Error installing cron entry. Bad syntax in fields ?</source>
        <translation>插入cron条目时出错。请检查语法。</translation>
    </message>
</context>
<context>
    <name>EditDialog</name>
    <message>
        <source>Dialog</source>
        <translation>对话框</translation>
    </message>
</context>
<context>
    <name>EditTransBase</name>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">取消</translation>
    </message>
</context>
<context>
    <name>FirstIdxDialog</name>
    <message>
        <source>First indexing setup</source>
        <translation>第一次索引设置</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;It appears that the index for this configuration does not exist.&lt;/span&gt;&lt;br /&gt;&lt;br /&gt;If you just want to index your home directory with a set of reasonable defaults, press the &lt;span style=&quot; font-style:italic;&quot;&gt;Start indexing now&lt;/span&gt; button. You will be able to adjust the details later. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you want more control, use the following links to adjust the indexing configuration and schedule.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;These tools can be accessed later from the &lt;span style=&quot; font-style:italic;&quot;&gt;Preferences&lt;/span&gt; menu.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;
&lt;!DOCTYPE html PUBLIC &quot;-//W3C//DTD XHTML 1.1 plus MathML 2.0//EN&quot; &quot;http://www.w3.org/Math/DTD/mathml2/xhtml-math11-f.dtd&quot;&gt;
&lt;html xmlns=&quot;http://www.w3.org/1999/xhtml&quot;&gt;&lt;!--This file was converted to xhtml by OpenOffice.org - see http://xml.openoffice.org/odf2xhtml for more info.--&gt;&lt;head profile=&quot;http://dublincore.org/documents/dcmi-terms/&quot;&gt;&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;application/xhtml+xml; charset=utf-8&quot;/&gt;&lt;title xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; ns_1:lang=&quot;en-US&quot;&gt;- no title specified&lt;/title&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.title&quot; content=&quot;&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;meta name=&quot;DCTERMS.language&quot; content=&quot;en-US&quot; scheme=&quot;DCTERMS.RFC4646&quot;/&gt;&lt;meta name=&quot;DCTERMS.source&quot; content=&quot;http://xml.openoffice.org/odf2xhtml&quot;/&gt;&lt;meta name=&quot;DCTERMS.issued&quot; content=&quot;2012-03-22T20:14:44&quot; scheme=&quot;DCTERMS.W3CDTF&quot;/&gt;&lt;meta name=&quot;DCTERMS.modified&quot; content=&quot;2012-03-22T20:23:13&quot; scheme=&quot;DCTERMS.W3CDTF&quot;/&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.provenance&quot; content=&quot;&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.subject&quot; content=&quot;,&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;link rel=&quot;schema.DC&quot; href=&quot;http://purl.org/dc/elements/1.1/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCTERMS&quot; href=&quot;http://purl.org/dc/terms/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCTYPE&quot; href=&quot;http://purl.org/dc/dcmitype/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCAM&quot; href=&quot;http://purl.org/dc/dcam/&quot; hreflang=&quot;en&quot;/&gt;&lt;style type=&quot;text/css&quot;&gt;
	@page {  }
	table { border-collapse:collapse; border-spacing:0; empty-cells:show }
	td, th { vertical-align:top; font-size:12pt;}
	h1, h2, h3, h4, h5, h6 { clear:both }
	ol, ul { margin:0; padding:0;}
	li { list-style: none; margin:0; padding:0;}
	&lt;!-- &quot;li span.odfLiEnd&quot; - IE 7 issue--&gt;
	li span. { clear: both; line-height:0; width:0; height:0; margin:0; padding:0; }
	span.footnodeNumber { padding-right:1em; }
	span.annotation_style_by_filter { font-size:95%; font-family:Arial; background-color:#fff000;  margin:0; border:0; padding:0;  }
	* { margin:0;}
	.P1 { font-size:12pt; margin-bottom:0cm; margin-top:0cm; font-family:Nimbus Roman No9 L; writing-mode:page; margin-left:0cm; margin-right:0cm; text-indent:0cm; }
	.T2 { font-weight:bold; }
	.T4 { font-style:italic; }
	&lt;!-- ODF styles with no properties representable as CSS --&gt;
	{ }
	&lt;/style&gt;&lt;/head&gt;&lt;body dir=&quot;ltr&quot; style=&quot;max-width:21.001cm;margin-top:2cm; margin-bottom:2cm; margin-left:2cm; margin-right:2cm; writing-mode:lr-tb; &quot;&gt;&lt;p class=&quot;P1&quot;&gt;&lt;span class=&quot;T2&quot;&gt;未找到对应于此配置实例的索引数据。&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;如果你只想以一组合理的默认参数来索引你的家目录的话，就直接按&lt;span class=&quot;T4&quot;&gt;立即开始索引&lt;/span&gt;按钮。以后还可以调整配置参数的。&lt;/p&gt;&lt;p class=&quot;P1&quot;&gt;如果你想调整某些东西的话，就使用下面的链接来调整其中的索引配置和定时计划吧。&lt;/p&gt;&lt;p class=&quot;P1&quot;&gt;这些工具可在以后通过&lt;span class=&quot;T4&quot;&gt;选项&lt;/span&gt;菜单访问。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</translation>
    </message>
    <message>
        <source>Indexing configuration</source>
        <translation>索引配置</translation>
    </message>
    <message>
        <source>This will let you adjust the directories you want to index, and other parameters like excluded file paths or names, default character sets, etc.</source>
        <translation>在这里可以调整你想要对其进行索引的目录，以及其它参数，例如：要排除和路径或名字、默认字符集……</translation>
    </message>
    <message>
        <source>Indexing schedule</source>
        <translation>定时索引任务</translation>
    </message>
    <message>
        <source>This will let you chose between batch and real-time indexing, and set up an automatic  schedule for batch indexing (using cron).</source>
        <translation>在这里可以选择是要进行批量索引还是实时索引，还可以设置一个自动化的定时（使用cron）批量索引任务。</translation>
    </message>
    <message>
        <source>Start indexing now</source>
        <translation>立即开始索引</translation>
    </message>
</context>
<context>
    <name>FragButs</name>
    <message>
        <source>%1 not found.</source>
        <translation>%1 未找到。</translation>
    </message>
    <message>
        <source>%1:
 %2</source>
        <translation>文本片段：％1：％2</translation>
    </message>
    <message>
        <source>Query Fragments</source>
        <translation>查询片段</translation>
    </message>
</context>
<context>
    <name>IdxSchedW</name>
    <message>
        <source>Index scheduling setup</source>
        <translation>定时索引设置</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Recoll&lt;/span&gt; indexing can run permanently, indexing files as they change, or run at discrete intervals. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Reading the manual may help you to decide between these approaches (press F1). &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This tool can help you set up a schedule to automate batch indexing runs, or start real time indexing when you log in (or both, which rarely makes sense). &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;
&lt;!DOCTYPE html PUBLIC &quot;-//W3C//DTD XHTML 1.1 plus MathML 2.0//EN&quot; &quot;http://www.w3.org/Math/DTD/mathml2/xhtml-math11-f.dtd&quot;&gt;
&lt;html xmlns=&quot;http://www.w3.org/1999/xhtml&quot;&gt;&lt;!--This file was converted to xhtml by OpenOffice.org - see http://xml.openoffice.org/odf2xhtml for more info.--&gt;&lt;head profile=&quot;http://dublincore.org/documents/dcmi-terms/&quot;&gt;&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;application/xhtml+xml; charset=utf-8&quot;/&gt;&lt;title xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; ns_1:lang=&quot;en-US&quot;&gt;- no title specified&lt;/title&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.title&quot; content=&quot;&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;meta name=&quot;DCTERMS.language&quot; content=&quot;en-US&quot; scheme=&quot;DCTERMS.RFC4646&quot;/&gt;&lt;meta name=&quot;DCTERMS.source&quot; content=&quot;http://xml.openoffice.org/odf2xhtml&quot;/&gt;&lt;meta name=&quot;DCTERMS.issued&quot; content=&quot;2012-03-22T20:27:11&quot; scheme=&quot;DCTERMS.W3CDTF&quot;/&gt;&lt;meta name=&quot;DCTERMS.modified&quot; content=&quot;2012-03-22T20:30:49&quot; scheme=&quot;DCTERMS.W3CDTF&quot;/&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.provenance&quot; content=&quot;&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.subject&quot; content=&quot;,&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;link rel=&quot;schema.DC&quot; href=&quot;http://purl.org/dc/elements/1.1/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCTERMS&quot; href=&quot;http://purl.org/dc/terms/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCTYPE&quot; href=&quot;http://purl.org/dc/dcmitype/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCAM&quot; href=&quot;http://purl.org/dc/dcam/&quot; hreflang=&quot;en&quot;/&gt;&lt;style type=&quot;text/css&quot;&gt;
	@page {  }
	table { border-collapse:collapse; border-spacing:0; empty-cells:show }
	td, th { vertical-align:top; font-size:12pt;}
	h1, h2, h3, h4, h5, h6 { clear:both }
	ol, ul { margin:0; padding:0;}
	li { list-style: none; margin:0; padding:0;}
	&lt;!-- &quot;li span.odfLiEnd&quot; - IE 7 issue--&gt;
	li span. { clear: both; line-height:0; width:0; height:0; margin:0; padding:0; }
	span.footnodeNumber { padding-right:1em; }
	span.annotation_style_by_filter { font-size:95%; font-family:Arial; background-color:#fff000;  margin:0; border:0; padding:0;  }
	* { margin:0;}
	.P1 { font-size:12pt; margin-bottom:0cm; margin-top:0cm; font-family:Nimbus Roman No9 L; writing-mode:page; margin-left:0cm; margin-right:0cm; text-indent:0cm; }
	.T1 { font-weight:bold; }
	&lt;!-- ODF styles with no properties representable as CSS --&gt;
	{ }
	&lt;/style&gt;&lt;/head&gt;&lt;body dir=&quot;ltr&quot; style=&quot;max-width:21.001cm;margin-top:2cm; margin-bottom:2cm; margin-left:2cm; margin-right:2cm; writing-mode:lr-tb; &quot;&gt;&lt;p class=&quot;P1&quot;&gt;&lt;span class=&quot;T1&quot;&gt;Recoll&lt;/span&gt; 索引程序可持续运行并且在文件发生变化时对其进行索引，也可以间隔一定时间运行一次。&lt;/p&gt;&lt;p class=&quot;P1&quot;&gt;你可以读一下手册，以便更好地做出抉择（按F1）。&lt;/p&gt;&lt;p class=&quot;P1&quot;&gt;这个工具可帮助你设置一个自动进行批量索引的定时任务，或者设置成当你登录时便启动实时索引（或者两者同时进行，当然那几乎没有意义）。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</translation>
    </message>
    <message>
        <source>Cron scheduling</source>
        <translation>定时任务</translation>
    </message>
    <message>
        <source>The tool will let you decide at what time indexing should run and will install a crontab entry.</source>
        <translation>这个工具帮助你确定一个让索引运行的时间，它会插入一个crontab条目。</translation>
    </message>
    <message>
        <source>Real time indexing start up</source>
        <translation>实时索引设置</translation>
    </message>
    <message>
        <source>Decide if real time indexing will be started when you log in (only for the default index).</source>
        <translation>作出决定，是否要在登录时便启动实时索引（只对默认索引有效）。</translation>
    </message>
</context>
<context>
    <name>ListDialog</name>
    <message>
        <source>Dialog</source>
        <translation>对话框</translation>
    </message>
    <message>
        <source>GroupBox</source>
        <translation>分组框</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <source>No db directory in configuration</source>
        <translation>配置实例中没有数据库目录</translation>
    </message>
    <message>
        <source>&quot;history&quot; file is damaged or un(read)writeable, please check or remove it: </source>
        <translation type="vanished">&quot;history&quot;文件被损坏，或者不可（读）写，请检查一下或者删除它：</translation>
    </message>
    <message>
        <source>&quot;history&quot; file is damaged, please check or remove it: </source>
        <translation>&quot;历史&quot;文件已损坏，请检查或删除它：</translation>
    </message>
    <message>
        <source>Needs &quot;Show system tray icon&quot; to be set in preferences!
</source>
        <translation>需要在首选项中设置“显示系统托盘图标”！</translation>
    </message>
</context>
<context>
    <name>PTransEdit</name>
    <message>
        <source>Path in index</source>
        <translation>索引中的路径</translation>
    </message>
    <message>
        <source>Translated path</source>
        <translation>翻译后的路径</translation>
    </message>
    <message>
        <source>Config error</source>
        <translation>配置错误</translation>
    </message>
    <message>
        <source>Original path</source>
        <translation>原始路径</translation>
    </message>
    <message>
        <source>Local path</source>
        <translation>本地路径</translation>
    </message>
</context>
<context>
    <name>PTransEditBase</name>
    <message>
        <source>Path Translations</source>
        <translation>路径翻译</translation>
    </message>
    <message>
        <source>Select one or several file types, then use the controls in the frame below to change how they are processed</source>
        <translation>选择一个或多个文件类型，然后使用下方框架中的控件来更改它们的处理方式。</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>保存</translation>
    </message>
</context>
<context>
    <name>Preview</name>
    <message>
        <source>Close Tab</source>
        <translation type="vanished">关闭标签页</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Missing helper program: </source>
        <translation>缺少辅助程序：</translation>
    </message>
    <message>
        <source>Can&apos;t turn doc into internal representation for </source>
        <translation>无法为此文件将文档转换成内部表示方式：</translation>
    </message>
    <message>
        <source>Creating preview text</source>
        <translation>正在创建预览文本</translation>
    </message>
    <message>
        <source>Loading preview text into editor</source>
        <translation>正在将预览文本载入到编辑器中</translation>
    </message>
    <message>
        <source>&amp;Search for:</source>
        <translation>搜索（&amp;S）：</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>下一个（&amp;N）</translation>
    </message>
    <message>
        <source>&amp;Previous</source>
        <translation>上一个（&amp;P）</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <source>Match &amp;Case</source>
        <translation>匹配大小写（&amp;C）</translation>
    </message>
    <message>
        <source>Cannot create temporary directory: </source>
        <translation type="obsolete">无法创建临时目录：</translation>
    </message>
    <message>
        <source>Error while loading file</source>
        <translation type="vanished">文件载入出错</translation>
    </message>
    <message>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <source>Tab 1</source>
        <translation>选项卡1</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <source>Canceled</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Error loading the document: file missing.</source>
        <translation>加载文档时出错：文件丢失。</translation>
    </message>
    <message>
        <source>Error loading the document: no permission.</source>
        <translation>加载文档时出错：无权限。</translation>
    </message>
    <message>
        <source>Error loading: backend not configured.</source>
        <translation>加载错误：后端未配置。</translation>
    </message>
    <message>
        <source>Error loading the document: other handler error&lt;br&gt;Maybe the application is locking the file ?</source>
        <translation>加载文档时出错：其他处理程序错误&lt;br&gt;也许应用程序正在锁定文件？</translation>
    </message>
    <message>
        <source>Error loading the document: other handler error.</source>
        <translation>加载文档时出错：其他处理程序错误。</translation>
    </message>
    <message>
        <source>&lt;br&gt;Attempting to display from stored text.</source>
        <translation>尝试从存储的文本中显示。</translation>
    </message>
    <message>
        <source>Could not fetch stored text</source>
        <translation>无法获取存储的文本</translation>
    </message>
    <message>
        <source>Previous result document</source>
        <translation>之前的结果文档</translation>
    </message>
    <message>
        <source>Next result document</source>
        <translation>下一个结果文档</translation>
    </message>
    <message>
        <source>Preview Window</source>
        <translation>预览窗口</translation>
    </message>
    <message>
        <source>Close tab</source>
        <translation>关闭标签页</translation>
    </message>
    <message>
        <source>Close preview window</source>
        <translation>关闭预览窗口</translation>
    </message>
    <message>
        <source>Show next result</source>
        <translation>显示下一个结果</translation>
    </message>
    <message>
        <source>Show previous result</source>
        <translation>显示上一个结果</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>打印</translation>
    </message>
</context>
<context>
    <name>PreviewTextEdit</name>
    <message>
        <source>Show fields</source>
        <translation>显示字段</translation>
    </message>
    <message>
        <source>Show main text</source>
        <translation>显示主文本</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>打印</translation>
    </message>
    <message>
        <source>Print Current Preview</source>
        <translation>打印当前预览文本</translation>
    </message>
    <message>
        <source>Show image</source>
        <translation>显示图片</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>全选</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <source>Save document to file</source>
        <translation>将文档保存到文件</translation>
    </message>
    <message>
        <source>Fold lines</source>
        <translation>自动换行</translation>
    </message>
    <message>
        <source>Preserve indentation</source>
        <translation>保留缩进符</translation>
    </message>
    <message>
        <source>Open document</source>
        <translation>打开文档</translation>
    </message>
    <message>
        <source>Reload as Plain Text</source>
        <translation>重新加载为纯文本</translation>
    </message>
    <message>
        <source>Reload as HTML</source>
        <translation>重新加载为HTML</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Global parameters</source>
        <translation type="vanished">全局参数</translation>
    </message>
    <message>
        <source>Local parameters</source>
        <translation type="vanished">局部参数</translation>
    </message>
    <message>
        <source>&lt;b&gt;Customised subtrees</source>
        <translation>&lt;b&gt;自定义的子目录树</translation>
    </message>
    <message>
        <source>The list of subdirectories in the indexed hierarchy &lt;br&gt;where some parameters need to be redefined. Default: empty.</source>
        <translation>这是已索引的目录树中的一些子目录组成的列表&lt;br&gt;，它们的某些参数需要重定义。默认：空白。</translation>
    </message>
    <message>
        <source>&lt;i&gt;The parameters that follow are set either at the top level, if nothing&lt;br&gt;or an empty line is selected in the listbox above, or for the selected subdirectory.&lt;br&gt;You can add or remove directories by clicking the +/- buttons.</source>
        <translation type="vanished">&lt;i&gt;以下的参数，当你在上面的列表中不选中任何条目或者选中一个空行时，&lt;br&gt;就是针对顶级目录起作用的，否则便是对选中的子目录起作用的。&lt;br&gt;你可以点击+/-按钮，以便添加或删除目录。</translation>
    </message>
    <message>
        <source>Skipped names</source>
        <translation>要略过的文件名</translation>
    </message>
    <message>
        <source>These are patterns for file or directory  names which should not be indexed.</source>
        <translation type="vanished">具有这些模式的文件或目录不会被索引。</translation>
    </message>
    <message>
        <source>Default character set</source>
        <translation type="obsolete">默认字符集</translation>
    </message>
    <message>
        <source>This is the character set used for reading files which do not identify the character set internally, for example pure text files.&lt;br&gt;The default value is empty, and the value from the NLS environnement is used.</source>
        <translation type="obsolete">这是用来读取那些未标明自身的字符集的文件时所使用的字符集，例如纯文本文件。&lt;br&gt;默认值是空，会使用系统里的自然语言环境参数中的值。</translation>
    </message>
    <message>
        <source>Follow symbolic links</source>
        <translation>跟踪符号链接</translation>
    </message>
    <message>
        <source>Follow symbolic links while indexing. The default is no, to avoid duplicate indexing</source>
        <translation>在索引时跟踪符号链接。默认是不跟踪的，以避免重复索引</translation>
    </message>
    <message>
        <source>Index all file names</source>
        <translation>对所有文件名进行索引</translation>
    </message>
    <message>
        <source>Index the names of files for which the contents cannot be identified or processed (no or unsupported mime type). Default true</source>
        <translation>对那些无法判断或处理其内容（未知类型或其类型不被支持）的文件的名字进行索引。默认为是</translation>
    </message>
    <message>
        <source>Beagle web history</source>
        <translation type="obsolete">Beagle网页历史</translation>
    </message>
    <message>
        <source>Search parameters</source>
        <translation type="obsolete">搜索参数</translation>
    </message>
    <message>
        <source>Default&lt;br&gt;character set</source>
        <translation>默认字符集</translation>
    </message>
    <message>
        <source>Character set used for reading files which do not identify the character set internally, for example pure text files.&lt;br&gt;The default value is empty, and the value from the NLS environnement is used.</source>
        <translation>用于读取不在文件内部标识字符集的文件的字符集，例如纯文本文件。&lt;br&gt;默认值为空，并使用NLS环境中的值。</translation>
    </message>
    <message>
        <source>Ignored endings</source>
        <translation>忽略的结尾</translation>
    </message>
    <message>
        <source>These are file name endings for files which will be indexed by name only 
(no MIME type identification attempt, no decompression, no content indexing).</source>
        <translation type="vanished">这些是仅按名称索引的文件的文件名结尾（不尝试识别MIME类型，不解压缩，不进行内容索引）。</translation>
    </message>
    <message>
        <source>&lt;i&gt;The parameters that follow are set either at the top level, if nothing or an empty line is selected in the listbox above, or for the selected subdirectory. You can add or remove directories by clicking the +/- buttons.</source>
        <translation>随后的参数是在顶层设置的，如果在上面的列表框中没有选择任何内容或选择了空行，或者是为所选的子目录设置的。您可以通过单击“+/-”按钮来添加或删除目录。</translation>
    </message>
    <message>
        <source>These are patterns for file or directory names which should not be indexed.</source>
        <translation>这些是文件或目录名称的模式，不应该被索引。</translation>
    </message>
    <message>
        <source>noContentSuffixes configuration variable: these are file name endings for files which will be indexed by name only 
(no MIME type identification attempt, no decompression, no content indexing).</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QWidget</name>
    <message>
        <source>Create or choose save directory</source>
        <translation>创建或选择保存目录</translation>
    </message>
    <message>
        <source>Choose exactly one directory</source>
        <translation>选择一个目录</translation>
    </message>
    <message>
        <source>Could not read directory: </source>
        <translation>无法读取目录:</translation>
    </message>
    <message>
        <source>Unexpected file name collision, cancelling.</source>
        <translation>意外的文件名冲突，取消。</translation>
    </message>
    <message>
        <source>Cannot extract document: </source>
        <translation>无法提取文档：</translation>
    </message>
    <message>
        <source>&amp;Preview</source>
        <translation>预览（&amp;P）</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>打开（&amp;O）</translation>
    </message>
    <message>
        <source>Open With</source>
        <translation>打开方式</translation>
    </message>
    <message>
        <source>Run Script</source>
        <translation>运行脚本</translation>
    </message>
    <message>
        <source>Copy &amp;File Name</source>
        <translation type="obsolete">复制文件名（&amp;F）</translation>
    </message>
    <message>
        <source>Copy &amp;URL</source>
        <translation>复制路径（&amp;U）</translation>
    </message>
    <message>
        <source>&amp;Write to File</source>
        <translation>写入文件（&amp;W）</translation>
    </message>
    <message>
        <source>Save selection to files</source>
        <translation>将选择保存到文件</translation>
    </message>
    <message>
        <source>Preview P&amp;arent document/folder</source>
        <translation>预览上一级文档/目录（&amp;a）</translation>
    </message>
    <message>
        <source>&amp;Open Parent document/folder</source>
        <translation type="obsolete">打开上一级文档/目录（&amp;O）</translation>
    </message>
    <message>
        <source>Find &amp;similar documents</source>
        <translation>查找类似的文档（&amp;s）</translation>
    </message>
    <message>
        <source>Open &amp;Snippets window</source>
        <translation>打开“片段”窗口</translation>
    </message>
    <message>
        <source>Show subdocuments / attachments</source>
        <translation>显示子文档/附件</translation>
    </message>
    <message>
        <source>&amp;Open Parent document</source>
        <translation>打开父文档</translation>
    </message>
    <message>
        <source>&amp;Open Parent Folder</source>
        <translation>打开父文件夹</translation>
    </message>
    <message>
        <source>Copy Text</source>
        <translation>复制文本</translation>
    </message>
    <message>
        <source>Copy &amp;File Path</source>
        <translation>复制文件路径</translation>
    </message>
    <message>
        <source>Copy File Name</source>
        <translation>复制文件名</translation>
    </message>
</context>
<context>
    <name>QxtConfirmationMessage</name>
    <message>
        <source>Do not show again.</source>
        <translation>不再显示。</translation>
    </message>
</context>
<context>
    <name>RTIToolW</name>
    <message>
        <source>Real time indexing automatic start</source>
        <translation>实时索引自动启动</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Recoll&lt;/span&gt; indexing can be set up to run as a daemon, updating the index as files change, in real time. You gain an always up to date index, but system resources are used permanently.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;
&lt;!DOCTYPE html PUBLIC &quot;-//W3C//DTD XHTML 1.1 plus MathML 2.0//EN&quot; &quot;http://www.w3.org/Math/DTD/mathml2/xhtml-math11-f.dtd&quot;&gt;
&lt;html xmlns=&quot;http://www.w3.org/1999/xhtml&quot;&gt;&lt;!--This file was converted to xhtml by OpenOffice.org - see http://xml.openoffice.org/odf2xhtml for more info.--&gt;&lt;head profile=&quot;http://dublincore.org/documents/dcmi-terms/&quot;&gt;&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;application/xhtml+xml; charset=utf-8&quot;/&gt;&lt;title xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; ns_1:lang=&quot;en-US&quot;&gt;- no title specified&lt;/title&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.title&quot; content=&quot;&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;meta name=&quot;DCTERMS.language&quot; content=&quot;en-US&quot; scheme=&quot;DCTERMS.RFC4646&quot;/&gt;&lt;meta name=&quot;DCTERMS.source&quot; content=&quot;http://xml.openoffice.org/odf2xhtml&quot;/&gt;&lt;meta name=&quot;DCTERMS.issued&quot; content=&quot;2012-03-22T21:00:38&quot; scheme=&quot;DCTERMS.W3CDTF&quot;/&gt;&lt;meta name=&quot;DCTERMS.modified&quot; content=&quot;2012-03-22T21:02:43&quot; scheme=&quot;DCTERMS.W3CDTF&quot;/&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.provenance&quot; content=&quot;&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.subject&quot; content=&quot;,&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;link rel=&quot;schema.DC&quot; href=&quot;http://purl.org/dc/elements/1.1/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCTERMS&quot; href=&quot;http://purl.org/dc/terms/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCTYPE&quot; href=&quot;http://purl.org/dc/dcmitype/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCAM&quot; href=&quot;http://purl.org/dc/dcam/&quot; hreflang=&quot;en&quot;/&gt;&lt;style type=&quot;text/css&quot;&gt;
	@page {  }
	table { border-collapse:collapse; border-spacing:0; empty-cells:show }
	td, th { vertical-align:top; font-size:12pt;}
	h1, h2, h3, h4, h5, h6 { clear:both }
	ol, ul { margin:0; padding:0;}
	li { list-style: none; margin:0; padding:0;}
	&lt;!-- &quot;li span.odfLiEnd&quot; - IE 7 issue--&gt;
	li span. { clear: both; line-height:0; width:0; height:0; margin:0; padding:0; }
	span.footnodeNumber { padding-right:1em; }
	span.annotation_style_by_filter { font-size:95%; font-family:Arial; background-color:#fff000;  margin:0; border:0; padding:0;  }
	* { margin:0;}
	.P1 { font-size:12pt; margin-bottom:0cm; margin-top:0cm; font-family:Nimbus Roman No9 L; writing-mode:page; margin-left:0cm; margin-right:0cm; text-indent:0cm; }
	.T1 { font-weight:bold; }
	&lt;!-- ODF styles with no properties representable as CSS --&gt;
	{ }
	&lt;/style&gt;&lt;/head&gt;&lt;body dir=&quot;ltr&quot; style=&quot;max-width:21.001cm;margin-top:2cm; margin-bottom:2cm; margin-left:2cm; margin-right:2cm; writing-mode:lr-tb; &quot;&gt;&lt;p class=&quot;P1&quot;&gt;&lt;span class=&quot;T1&quot;&gt;Recoll&lt;/span&gt; 索引程序可以以守护进程的方式运行，在文件发生变化时便实时更新索引。这样你的索引一直是与文件同步的，但是会占用一定的系统资源。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</translation>
    </message>
    <message>
        <source>Start indexing daemon with my desktop session.</source>
        <translation>在我的桌面会话启动时便启动索引进程。</translation>
    </message>
    <message>
        <source>Also start indexing daemon right now.</source>
        <translation>同时此次也立即启动索引进程。</translation>
    </message>
    <message>
        <source>Replacing: </source>
        <translation>正在替换：</translation>
    </message>
    <message>
        <source>Replacing file</source>
        <translation>正在替换文件</translation>
    </message>
    <message>
        <source>Can&apos;t create: </source>
        <translation>无法创建：</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <source>Could not execute recollindex</source>
        <translation>无法执行recollindex</translation>
    </message>
    <message>
        <source>Deleting: </source>
        <translation>正在删除：</translation>
    </message>
    <message>
        <source>Deleting file</source>
        <translation>正在删除文件</translation>
    </message>
    <message>
        <source>Removing autostart</source>
        <translation>正在删除自动启动项</translation>
    </message>
    <message>
        <source>Autostart file deleted. Kill current process too ?</source>
        <translation>自动启动文件已经删除。也要杀死当前进程吗？</translation>
    </message>
    <message>
        <source>Configuration name</source>
        <translation>配置名称</translation>
    </message>
    <message>
        <source>Short alphanumeric nickname for this config</source>
        <translation>这个配置的简短字母数字昵称</translation>
    </message>
    <message>
        <source>Could not find </source>
        <translation>无法找到</translation>
    </message>
</context>
<context>
    <name>RclCompleterModel</name>
    <message>
        <source>Hits</source>
        <translation type="obsolete">点击量</translation>
    </message>
    <message>
        <source> Hits</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RclMain</name>
    <message>
        <source>(no stemming)</source>
        <translation>（不进行词根计算）</translation>
    </message>
    <message>
        <source>(all languages)</source>
        <translation>（对全部语言进行词根计算）</translation>
    </message>
    <message>
        <source>error retrieving stemming languages</source>
        <translation>提取词根语言时出错</translation>
    </message>
    <message>
        <source>Indexing in progress: </source>
        <translation>正在索引：</translation>
    </message>
    <message>
        <source>Purge</source>
        <translation>删除</translation>
    </message>
    <message>
        <source>Stemdb</source>
        <translation>Stem数据库</translation>
    </message>
    <message>
        <source>Closing</source>
        <translation>正在关闭</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <source>Query results</source>
        <translation>查询结果</translation>
    </message>
    <message>
        <source>Cannot retrieve document info from database</source>
        <translation>无法从数据库获取文档信息</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <source>Can&apos;t create preview window</source>
        <translation>无法创建预览窗口</translation>
    </message>
    <message>
        <source>This search is not active any more</source>
        <translation type="vanished">这个查询已经不是活跃的了</translation>
    </message>
    <message>
        <source>Bad viewer command line for %1: [%2]
Please check the mimeconf file</source>
        <translation type="obsolete">针对%1的查看命令[%2]配置出错
请检查mimeconf文件</translation>
    </message>
    <message>
        <source>Cannot extract document or create temporary file</source>
        <translation>无法提取文档或创建临时文件</translation>
    </message>
    <message>
        <source>Executing: [</source>
        <translation>正在执行：[</translation>
    </message>
    <message>
        <source>About Recoll</source>
        <translation>Recoll说明</translation>
    </message>
    <message>
        <source>History data</source>
        <translation>历史数据</translation>
    </message>
    <message>
        <source>Document history</source>
        <translation>文档历史</translation>
    </message>
    <message>
        <source>Update &amp;Index</source>
        <translation>更新索引（&amp;I）</translation>
    </message>
    <message>
        <source>Stop &amp;Indexing</source>
        <translation>停止索引（&amp;I）</translation>
    </message>
    <message>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <source>media</source>
        <translation>多媒体文件</translation>
    </message>
    <message>
        <source>message</source>
        <translation>邮件</translation>
    </message>
    <message>
        <source>other</source>
        <translation>其它</translation>
    </message>
    <message>
        <source>presentation</source>
        <translation>演示文档</translation>
    </message>
    <message>
        <source>spreadsheet</source>
        <translation>电子表格</translation>
    </message>
    <message>
        <source>text</source>
        <translation>文本文件</translation>
    </message>
    <message>
        <source>sorted</source>
        <translation>已排序</translation>
    </message>
    <message>
        <source>filtered</source>
        <translation>已过滤</translation>
    </message>
    <message>
        <source>External applications/commands needed and not found for indexing your file types:

</source>
        <translation type="obsolete">需要用来辅助对你的文件进行索引，却又找不到的外部程序/命令：

</translation>
    </message>
    <message>
        <source>No helpers found missing</source>
        <translation>目前不缺少任何辅助程序</translation>
    </message>
    <message>
        <source>Missing helper programs</source>
        <translation>未找到的辅助程序</translation>
    </message>
    <message>
        <source>Document category filter</source>
        <translation type="obsolete">文档分类过滤器</translation>
    </message>
    <message>
        <source>No external viewer configured for mime type [</source>
        <translation>针对此种文件类型没有配置外部查看器[</translation>
    </message>
    <message>
        <source>The viewer specified in mimeview for %1: %2 is not found.
Do you want to start the  preferences dialog ?</source>
        <translation type="vanished">没有找到mimeview中为%1: %2配置的查看器。
是否要打开选项对话框？</translation>
    </message>
    <message>
        <source>Can&apos;t access file: </source>
        <translation>无法访问文件：</translation>
    </message>
    <message>
        <source>Can&apos;t uncompress file: </source>
        <translation>无法解压缩此文件：</translation>
    </message>
    <message>
        <source>Save file</source>
        <translation>保存文件</translation>
    </message>
    <message>
        <source>Result count (est.)</source>
        <translation>结果数（估计值）</translation>
    </message>
    <message>
        <source>Query details</source>
        <translation type="obsolete">查询语句细节</translation>
    </message>
    <message>
        <source>Could not open external index. Db not open. Check external index list.</source>
        <translation>无法打开外部索引。数据库未打开。请检查外部索引列表。</translation>
    </message>
    <message>
        <source>No results found</source>
        <translation>未找到结果</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Updating</source>
        <translation>正在更新</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>已完成</translation>
    </message>
    <message>
        <source>Monitor</source>
        <translation>监视器</translation>
    </message>
    <message>
        <source>Indexing failed</source>
        <translation>索引失败</translation>
    </message>
    <message>
        <source>The current indexing process was not started from this interface. Click Ok to kill it anyway, or Cancel to leave it alone</source>
        <translation type="vanished">当前索引进程不是由此界面启动的。点击确定以杀死它，或者点击取消以让它自由运行</translation>
    </message>
    <message>
        <source>Erasing index</source>
        <translation>正在删除索引</translation>
    </message>
    <message>
        <source>Reset the index and start from scratch ?</source>
        <translation>从头重新开始索引吗？</translation>
    </message>
    <message>
        <source>Query in progress.&lt;br&gt;Due to limitations of the indexing library,&lt;br&gt;cancelling will exit the program</source>
        <translation>查询正在进行中。&lt;br&gt;由于索引库的某些限制，&lt;br&gt;取消的话会导致程序退出</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>Index not open</source>
        <translation type="vanished">索引未打开</translation>
    </message>
    <message>
        <source>Index query error</source>
        <translation>索引查询出错</translation>
    </message>
    <message>
        <source>Content has been indexed for these mime types:</source>
        <translation type="vanished">已经为这些文件类型索引其内容：</translation>
    </message>
    <message>
        <source>Index not up to date for this file. Refusing to risk showing the wrong entry. Click Ok to update the index for this file, then re-run the query when indexing is done. Else, Cancel.</source>
        <translation type="obsolete">此文件的索引已过时。程序拒绝显示错误的条目。请点击确定以更新此文件的索引，等待索引完成之后再查询。或者，取消。</translation>
    </message>
    <message>
        <source>Can&apos;t update index: indexer running</source>
        <translation>无法更新索引：索引程序已在运行</translation>
    </message>
    <message>
        <source>Indexed MIME Types</source>
        <translation>已索引的文件类型</translation>
    </message>
    <message>
        <source>Bad viewer command line for %1: [%2]
Please check the mimeview file</source>
        <translation>%1的查看器命令行错误：[%2]
请检查mimeview文件</translation>
    </message>
    <message>
        <source>Viewer command line for %1 specifies both file and parent file value: unsupported</source>
        <translation>%1的查看器命令行同时指定文件和父文件值：不支持</translation>
    </message>
    <message>
        <source>Cannot find parent document</source>
        <translation>无法找到父文档</translation>
    </message>
    <message>
        <source>External applications/commands needed for your file types and not found, as stored by the last indexing pass in </source>
        <translation>您文件类型所需的外部应用程序/命令未找到，如上次索引过程中存储的。</translation>
    </message>
    <message>
        <source>Sub-documents and attachments</source>
        <translation>子文档和附件</translation>
    </message>
    <message>
        <source>Document filter</source>
        <translation>文档过滤器</translation>
    </message>
    <message>
        <source>The indexer is running so things should improve when it&apos;s done. </source>
        <translation>索引器正在运行，当它完成时，情况应该会有所改善。</translation>
    </message>
    <message>
        <source>Bad desktop app spec for %1: [%2]
Please check the desktop file</source>
        <translation>%1的桌面应用程序规范不好：[%2]
请检查桌面文件</translation>
    </message>
    <message>
        <source>Indexing interrupted</source>
        <translation>索引中断</translation>
    </message>
    <message>
        <source>Bad paths</source>
        <translation>不良路径</translation>
    </message>
    <message>
        <source>Selection patterns need topdir</source>
        <translation>选择模式需要顶级目录</translation>
    </message>
    <message>
        <source>Selection patterns can only be used with a start directory</source>
        <translation>选择模式只能与起始目录一起使用。</translation>
    </message>
    <message>
        <source>No search</source>
        <translation>没有搜索</translation>
    </message>
    <message>
        <source>No preserved previous search</source>
        <translation>没有保存之前的搜索</translation>
    </message>
    <message>
        <source>Choose file to save</source>
        <translation>选择要保存的文件</translation>
    </message>
    <message>
        <source>Saved Queries (*.rclq)</source>
        <translation>保存的查询 (*.rclq)</translation>
    </message>
    <message>
        <source>Write failed</source>
        <translation>写入失败</translation>
    </message>
    <message>
        <source>Could not write to file</source>
        <translation>无法写入文件</translation>
    </message>
    <message>
        <source>Read failed</source>
        <translation>读取失败</translation>
    </message>
    <message>
        <source>Could not open file: </source>
        <translation>无法打开文件：</translation>
    </message>
    <message>
        <source>Load error</source>
        <translation>加载错误</translation>
    </message>
    <message>
        <source>Could not load saved query</source>
        <translation>无法加载保存的查询</translation>
    </message>
    <message>
        <source>Disabled because the real time indexer was not compiled in.</source>
        <translation>因为实时索引器未编译，所以被禁用。</translation>
    </message>
    <message>
        <source>Can&apos;t set synonyms file (parse error?)</source>
        <translation>无法设置同义词文件（解析错误？）</translation>
    </message>
    <message>
        <source>The document belongs to an external index which I can&apos;t update. </source>
        <translation>该文档属于一个我无法更新的外部索引。</translation>
    </message>
    <message>
        <source>Opening a temporary copy. Edits will be lost if you don&apos;t save&lt;br/&gt;them to a permanent location.</source>
        <translation>打开一个临时副本。如果您不将其保存到永久位置，编辑将会丢失。</translation>
    </message>
    <message>
        <source>Do not show this warning next time (use GUI preferences to restore).</source>
        <translation>不要在下次显示此警告（使用GUI首选项来恢复）。</translation>
    </message>
    <message>
        <source>Index locked</source>
        <translation>索引已锁定</translation>
    </message>
    <message>
        <source>Unknown indexer state. Can&apos;t access webcache file.</source>
        <translation>未知的索引器状态。无法访问网络缓存文件。</translation>
    </message>
    <message>
        <source>Indexer is running. Can&apos;t access webcache file.</source>
        <translation>索引器正在运行。无法访问网络缓存文件。</translation>
    </message>
    <message>
        <source>with additional message: </source>
        <translation type="obsolete">带有附加消息:</translation>
    </message>
    <message>
        <source>Non-fatal indexing message: </source>
        <translation>非致命性索引消息:</translation>
    </message>
    <message>
        <source>Types list empty: maybe wait for indexing to progress?</source>
        <translation>类型列表为空：也许等待索引进展？</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>工具</translation>
    </message>
    <message>
        <source>Results</source>
        <translation>结果</translation>
    </message>
    <message>
        <source>Content has been indexed for these MIME types:</source>
        <translation>这些 MIME 类型的内容已被索引：</translation>
    </message>
    <message>
        <source>Empty or non-existant paths in configuration file. Click Ok to start indexing anyway (absent data will not be purged from the index):
</source>
        <translation>配置文件中存在空路径或不存在的路径。单击“确定”以继续进行索引（缺失的数据将不会从索引中清除）。</translation>
    </message>
    <message>
        <source>Indexing done</source>
        <translation>索引完成</translation>
    </message>
    <message>
        <source>Can&apos;t update index: internal error</source>
        <translation>无法更新索引：内部错误</translation>
    </message>
    <message>
        <source>Index not up to date for this file.&lt;br&gt;</source>
        <translation>该文件的索引尚未更新。</translation>
    </message>
    <message>
        <source>&lt;em&gt;Also, it seems that the last index update for the file failed.&lt;/em&gt;&lt;br/&gt;</source>
        <translation>此外，似乎文件的最后索引更新失败了。&lt;br/&gt;</translation>
    </message>
    <message>
        <source>Click Ok to try to update the index for this file. You will need to run the query again when indexing is done.&lt;br&gt;</source>
        <translation>点击“确定”尝试更新此文件的索引。索引完成后，您需要重新运行查询。</translation>
    </message>
    <message>
        <source>Click Cancel to return to the list.&lt;br&gt;Click Ignore to show the preview anyway (and remember for this session). There is a risk of showing the wrong entry.&lt;br/&gt;</source>
        <translation>点击取消返回到列表。&lt;br&gt;点击忽略仍然显示预览（并记住本次会话）。有显示错误条目的风险。</translation>
    </message>
    <message>
        <source>documents</source>
        <translation>文件</translation>
    </message>
    <message>
        <source>document</source>
        <translation>文档</translation>
    </message>
    <message>
        <source>files</source>
        <translation>文件</translation>
    </message>
    <message>
        <source>file</source>
        <translation>文件</translation>
    </message>
    <message>
        <source>errors</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>error</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>total files)</source>
        <translation>总文件数)</translation>
    </message>
    <message>
        <source>No information: initial indexing not yet performed.</source>
        <translation>无信息：尚未执行初始索引。</translation>
    </message>
    <message>
        <source>Batch scheduling</source>
        <translation>批量调度</translation>
    </message>
    <message>
        <source>The tool will let you decide at what time indexing should run.  It uses the Windows task scheduler.</source>
        <translation>该工具将让您决定索引何时运行。它使用Windows任务计划程序。</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <source>Erasing simple and advanced search history lists, please click Ok to confirm</source>
        <translation>擦除简单和高级搜索历史记录，请点击“确定”确认。</translation>
    </message>
    <message>
        <source>Could not open/create file</source>
        <translation>无法打开/创建文件</translation>
    </message>
    <message>
        <source>F&amp;ilter</source>
        <translation>过滤</translation>
    </message>
    <message>
        <source>Simple search type</source>
        <translation>简单搜索类型</translation>
    </message>
    <message>
        <source>Any term</source>
        <translation>任一词语</translation>
    </message>
    <message>
        <source>All terms</source>
        <translation>全部词语</translation>
    </message>
    <message>
        <source>File name</source>
        <translation>文件名</translation>
    </message>
    <message>
        <source>Query language</source>
        <translation>查询语言</translation>
    </message>
    <message>
        <source>Stemming language</source>
        <translation>词根语言</translation>
    </message>
    <message>
        <source>Main Window</source>
        <translation>主窗口</translation>
    </message>
    <message>
        <source>Clear search</source>
        <translation>清除搜索</translation>
    </message>
    <message>
        <source>Move keyboard focus to search entry</source>
        <translation>将键盘焦点移动到搜索输入框。</translation>
    </message>
    <message>
        <source>Move keyboard focus to search, alt.</source>
        <translation>将键盘焦点移动到搜索框，按下Alt键。</translation>
    </message>
    <message>
        <source>Toggle tabular display</source>
        <translation>切换表格显示</translation>
    </message>
    <message>
        <source>Move keyboard focus to table</source>
        <translation>将键盘焦点移动到表格。</translation>
    </message>
    <message>
        <source>Flushing</source>
        <translation>刷新</translation>
    </message>
    <message>
        <source>Show menu search dialog</source>
        <translation>显示菜单搜索对话框</translation>
    </message>
    <message>
        <source>Duplicates</source>
        <translation>重复项</translation>
    </message>
    <message>
        <source>Filter directories</source>
        <translation>过滤目录</translation>
    </message>
    <message>
        <source>This search is not active anymore</source>
        <translation>这个搜索不再处于活动状态。</translation>
    </message>
    <message>
        <source>The viewer specified in mimeview for %1: %2 is not found.
Do you want to start the preferences dialog ?</source>
        <translation>在mimeview中为%1指定的查看器未找到：%2。
您想要启动首选项对话框吗？</translation>
    </message>
    <message>
        <source>Viewer command line for %1 specifies parent file but URL is not file:// : unsupported</source>
        <translation>查看器命令行为%1指定了父文件，但URL不是file://：不支持</translation>
    </message>
    <message>
        <source>Show advanced search dialog</source>
        <translation>显示高级搜索对话框</translation>
    </message>
    <message>
        <source>Main index open error: </source>
        <translation>主索引打开错误：</translation>
    </message>
    <message>
        <source>. The index may be corrupted. Maybe try to run xapian-check or rebuild the index ?.</source>
        <translation>索引可能已损坏。也许尝试运行xapian-check或重建索引？</translation>
    </message>
    <message>
        <source> with additional message: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Semantic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RclMainBase</name>
    <message>
        <source>Recoll</source>
        <translation>Recoll</translation>
    </message>
    <message>
        <source>Search tools</source>
        <translation type="obsolete">搜索工具</translation>
    </message>
    <message>
        <source>Result list</source>
        <translation type="obsolete">结果列表</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>文件（&amp;F）</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>工具（&amp;T）</translation>
    </message>
    <message>
        <source>&amp;Preferences</source>
        <translation>选项（&amp;P）</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>帮助（&amp;H）</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>退出（&amp;x）</translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <source>Update &amp;index</source>
        <translation>更新索引（&amp;i）</translation>
    </message>
    <message>
        <source>&amp;Erase document history</source>
        <translation>删除文档历史（&amp;E）</translation>
    </message>
    <message>
        <source>&amp;About Recoll</source>
        <translation>Recoll说明（&amp;A）</translation>
    </message>
    <message>
        <source>&amp;User manual</source>
        <translation type="vanished">用户手册（&amp;U）</translation>
    </message>
    <message>
        <source>Document &amp;History</source>
        <translation>文档历史（&amp;H）</translation>
    </message>
    <message>
        <source>Document  History</source>
        <translation>文档历史</translation>
    </message>
    <message>
        <source>&amp;Advanced Search</source>
        <translation>高端搜索（&amp;A）</translation>
    </message>
    <message>
        <source>Advanced/complex  Search</source>
        <translation type="vanished">高端/复杂搜索</translation>
    </message>
    <message>
        <source>&amp;Sort parameters</source>
        <translation>排序参数（&amp;S）</translation>
    </message>
    <message>
        <source>Sort parameters</source>
        <translation>排序参数</translation>
    </message>
    <message>
        <source>Term &amp;explorer</source>
        <translation>词语探索器（&amp;e）</translation>
    </message>
    <message>
        <source>Term explorer tool</source>
        <translation>词语探索器</translation>
    </message>
    <message>
        <source>Next page</source>
        <translation>下一页</translation>
    </message>
    <message>
        <source>Next page of results</source>
        <translation>下一页结果</translation>
    </message>
    <message>
        <source>First page</source>
        <translation>第一页</translation>
    </message>
    <message>
        <source>Go to first page of results</source>
        <translation>跳转到结果的第一页</translation>
    </message>
    <message>
        <source>Previous page</source>
        <translation>上一页</translation>
    </message>
    <message>
        <source>Previous page of results</source>
        <translation>上一页结果</translation>
    </message>
    <message>
        <source>&amp;Query configuration</source>
        <translation type="obsolete">查询配置（&amp;Q）</translation>
    </message>
    <message>
        <source>External index dialog</source>
        <translation>外部索引对话框</translation>
    </message>
    <message>
        <source>&amp;Indexing configuration</source>
        <translation type="obsolete">索引配置（&amp;I）</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="obsolete">全部</translation>
    </message>
    <message>
        <source>&amp;Show missing helpers</source>
        <translation type="obsolete">显示缺少的辅助程序列表（&amp;S）</translation>
    </message>
    <message>
        <source>PgDown</source>
        <translation>向下翻页</translation>
    </message>
    <message>
        <source>PgUp</source>
        <translation>向上翻页</translation>
    </message>
    <message>
        <source>&amp;Full Screen</source>
        <translation>全屏（&amp;F）</translation>
    </message>
    <message>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation>全屏</translation>
    </message>
    <message>
        <source>&amp;Erase search history</source>
        <translation>删除搜索历史（&amp;E）</translation>
    </message>
    <message>
        <source>sortByDateAsc</source>
        <translation type="obsolete">按日期升序排列</translation>
    </message>
    <message>
        <source>Sort by dates from oldest to newest</source>
        <translation>按日期排列，最旧的在前面</translation>
    </message>
    <message>
        <source>sortByDateDesc</source>
        <translation type="obsolete">按日期降序排列</translation>
    </message>
    <message>
        <source>Sort by dates from newest to oldest</source>
        <translation>按日期排列，最新的在前面</translation>
    </message>
    <message>
        <source>Show Query Details</source>
        <translation>显示查询语句细节</translation>
    </message>
    <message>
        <source>Show results as table</source>
        <translation type="obsolete">以表格的形式显示结果</translation>
    </message>
    <message>
        <source>&amp;Rebuild index</source>
        <translation>重新构造索引（&amp;R）</translation>
    </message>
    <message>
        <source>&amp;Show indexed types</source>
        <translation type="obsolete">显示已索引的文件类型（&amp;S）</translation>
    </message>
    <message>
        <source>Shift+PgUp</source>
        <translation>Shift+向上翻页</translation>
    </message>
    <message>
        <source>&amp;Indexing schedule</source>
        <translation type="obsolete">定时索引（&amp;I）</translation>
    </message>
    <message>
        <source>E&amp;xternal index dialog</source>
        <translation>外部索引对话框（&amp;x）</translation>
    </message>
    <message>
        <source>&amp;Index configuration</source>
        <translation>索引配置</translation>
    </message>
    <message>
        <source>&amp;GUI configuration</source>
        <translation>GUI配置</translation>
    </message>
    <message>
        <source>&amp;Results</source>
        <translation>搜索结果</translation>
    </message>
    <message>
        <source>Sort by date, oldest first</source>
        <translation>按日期排序，从最早开始</translation>
    </message>
    <message>
        <source>Sort by date, newest first</source>
        <translation>按日期排序，最新的在前</translation>
    </message>
    <message>
        <source>Show as table</source>
        <translation>显示为表格</translation>
    </message>
    <message>
        <source>Show results in a spreadsheet-like table</source>
        <translation>在类似电子表格的表格中显示结果</translation>
    </message>
    <message>
        <source>Save as CSV (spreadsheet) file</source>
        <translation>保存为CSV（电子表格）文件</translation>
    </message>
    <message>
        <source>Saves the result into a file which you can load in a spreadsheet</source>
        <translation>将结果保存到一个文件中，您可以在电子表格中加载。</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>下一页</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation>上一页</translation>
    </message>
    <message>
        <source>First Page</source>
        <translation>第一页</translation>
    </message>
    <message>
        <source>Query Fragments</source>
        <translation>查询片段</translation>
    </message>
    <message>
        <source>With failed files retrying</source>
        <translation type="obsolete">文件失败，正在重试</translation>
    </message>
    <message>
        <source>Next update will retry previously failed files</source>
        <translation>下一个更新将重试之前失败的文件。</translation>
    </message>
    <message>
        <source>Indexing &amp;schedule</source>
        <translation>索引和计划</translation>
    </message>
    <message>
        <source>Enable synonyms</source>
        <translation>启用同义词</translation>
    </message>
    <message>
        <source>Save last query</source>
        <translation>保存上次查询</translation>
    </message>
    <message>
        <source>Load saved query</source>
        <translation>加载保存的查询</translation>
    </message>
    <message>
        <source>Special Indexing</source>
        <translation>特殊索引</translation>
    </message>
    <message>
        <source>Indexing with special options</source>
        <translation>使用特殊选项进行索引化</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>查看</translation>
    </message>
    <message>
        <source>Missing &amp;helpers</source>
        <translation>缺失 &amp;helpers</translation>
    </message>
    <message>
        <source>Indexed &amp;MIME types</source>
        <translation>索引和MIME类型</translation>
    </message>
    <message>
        <source>Index &amp;statistics</source>
        <translation>索引和统计</translation>
    </message>
    <message>
        <source>Webcache Editor</source>
        <translation>Webcache编辑器</translation>
    </message>
    <message>
        <source>Trigger incremental pass</source>
        <translation>触发增量搜索</translation>
    </message>
    <message>
        <source>E&amp;xport simple search history</source>
        <translation>导出简单搜索历史</translation>
    </message>
    <message>
        <source>&amp;Query</source>
        <translation>查询</translation>
    </message>
    <message>
        <source>Increase results text font size</source>
        <translation>增加结果文本字体大小</translation>
    </message>
    <message>
        <source>Increase Font Size</source>
        <translation>增加字体大小</translation>
    </message>
    <message>
        <source>Decrease results text font size</source>
        <translation>减小结果文本字体大小</translation>
    </message>
    <message>
        <source>Decrease Font Size</source>
        <translation>减小字体大小</translation>
    </message>
    <message>
        <source>Start real time indexer</source>
        <translation>开始实时索引器</translation>
    </message>
    <message>
        <source>Query Language Filters</source>
        <translation>查询语言过滤器</translation>
    </message>
    <message>
        <source>Filter dates</source>
        <translation>过滤日期</translation>
    </message>
    <message>
        <source>Filter birth dates</source>
        <translation>过滤创建日期</translation>
    </message>
    <message>
        <source>Assisted complex search</source>
        <translation>辅助复杂搜索</translation>
    </message>
    <message>
        <source>&amp;User manual (local, one HTML page)</source>
        <translation>用户手册（本地，一个HTML页面）</translation>
    </message>
    <message>
        <source>&amp;Online manual (Recoll Web site)</source>
        <translation>在线手册（Recoll网站）</translation>
    </message>
    <message>
        <source>Path translations</source>
        <translation>路径翻译</translation>
    </message>
    <message>
        <source>Switch Configuration...</source>
        <translation>切换配置...</translation>
    </message>
    <message>
        <source>Choose another configuration to run on, replacing this process</source>
        <translation>选择另一个配置来运行，替换当前进程。</translation>
    </message>
    <message>
        <source>    With failed files retrying</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter file sizes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimum size (leave at 0 to disable)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum size (leave at 0 to disable)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Recoll Web site for current Windows version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query Language cheat sheet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RclTrayIcon</name>
    <message>
        <source>Restore</source>
        <translation>恢复</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>退出</translation>
    </message>
</context>
<context>
    <name>RecollModel</name>
    <message>
        <source>Abstract</source>
        <translation>摘要</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <source>Document size</source>
        <translation>文档尺寸</translation>
    </message>
    <message>
        <source>Document date</source>
        <translation>文档日期</translation>
    </message>
    <message>
        <source>File size</source>
        <translation>文件尺寸</translation>
    </message>
    <message>
        <source>File name</source>
        <translation>文件名</translation>
    </message>
    <message>
        <source>File date</source>
        <translation>文件日期</translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation>关键词</translation>
    </message>
    <message>
        <source>Original character set</source>
        <translation>原字符集</translation>
    </message>
    <message>
        <source>Relevancy rating</source>
        <translation>相关度</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>标题</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>路径</translation>
    </message>
    <message>
        <source>Mtime</source>
        <translation type="vanished">修改时间</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <source>Date and time</source>
        <translation>日期及时间</translation>
    </message>
    <message>
        <source>Ipath</source>
        <translation>内部路径</translation>
    </message>
    <message>
        <source>MIME type</source>
        <translation>文件类型</translation>
    </message>
    <message>
        <source>Can&apos;t sort by inverse relevance</source>
        <translation>无法按逆相关性排序</translation>
    </message>
    <message>
        <source>Saving to CSV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">取消</translation>
    </message>
</context>
<context>
    <name>ResList</name>
    <message>
        <source>Result list</source>
        <translation>结果列表</translation>
    </message>
    <message>
        <source>(show query)</source>
        <translation>（显示查询语句细节）</translation>
    </message>
    <message>
        <source>&amp;Preview</source>
        <translation type="obsolete">预览（&amp;P）</translation>
    </message>
    <message>
        <source>Copy &amp;File Name</source>
        <translation type="obsolete">复制文件名（&amp;F）</translation>
    </message>
    <message>
        <source>Copy &amp;URL</source>
        <translation type="obsolete">复制路径（&amp;U）</translation>
    </message>
    <message>
        <source>Find &amp;similar documents</source>
        <translation type="obsolete">查找类似的文档（&amp;s）</translation>
    </message>
    <message>
        <source>Document history</source>
        <translation>文档历史</translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;No results found&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;未找到结果&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation>上一页</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>下一页</translation>
    </message>
    <message>
        <source>Unavailable document</source>
        <translation>无法访问文档</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;i&gt;Alternate spellings (accents suppressed): &lt;/i&gt;</source>
        <translation>&lt;p&gt;&lt;i&gt;其它拼写形式（忽视口音）：&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&amp;Write to File</source>
        <translation type="obsolete">写入文件（&amp;W）</translation>
    </message>
    <message>
        <source>Preview P&amp;arent document/folder</source>
        <translation type="obsolete">预览上一级文档/目录（&amp;a）</translation>
    </message>
    <message>
        <source>&amp;Open Parent document/folder</source>
        <translation type="obsolete">打开上一级文档/目录（&amp;O）</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="obsolete">打开（&amp;O）</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>第</translation>
    </message>
    <message>
        <source>out of at least</source>
        <translation>个文档，最少共有</translation>
    </message>
    <message>
        <source>for</source>
        <translation>个文档，查询条件：</translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;i&gt;Alternate spellings: &lt;/i&gt;</source>
        <translation>&lt;p&gt;&lt;i&gt;备选拼写：&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Result count (est.)</source>
        <translation>结果数（估计值）</translation>
    </message>
    <message>
        <source>Query details</source>
        <translation>查询语句细节</translation>
    </message>
    <message>
        <source>Snippets</source>
        <translation>片段</translation>
    </message>
    <message>
        <source>This spelling guess was added to the search:</source>
        <translation>这个拼写猜测已添加到搜索中：</translation>
    </message>
    <message>
        <source>These spelling guesses were added to the search:</source>
        <translation>这些拼写猜测已添加到搜索中：</translation>
    </message>
</context>
<context>
    <name>ResTable</name>
    <message>
        <source>&amp;Reset sort</source>
        <translation>重置排序条件（&amp;R）</translation>
    </message>
    <message>
        <source>&amp;Delete column</source>
        <translation>删除此列（&amp;D）</translation>
    </message>
    <message>
        <source>Save table to CSV file</source>
        <translation>将表格保存成CSV文件</translation>
    </message>
    <message>
        <source>Can&apos;t open/create file: </source>
        <translation>无法打开/创建文件：</translation>
    </message>
    <message>
        <source>&amp;Preview</source>
        <translation type="obsolete">预览（&amp;P）</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="obsolete">打开（&amp;O）</translation>
    </message>
    <message>
        <source>Copy &amp;File Name</source>
        <translation type="obsolete">复制文件名（&amp;F）</translation>
    </message>
    <message>
        <source>Copy &amp;URL</source>
        <translation type="obsolete">复制路径（&amp;U）</translation>
    </message>
    <message>
        <source>&amp;Write to File</source>
        <translation type="obsolete">写入文件（&amp;W）</translation>
    </message>
    <message>
        <source>Find &amp;similar documents</source>
        <translation type="obsolete">查找类似的文档（&amp;s）</translation>
    </message>
    <message>
        <source>Preview P&amp;arent document/folder</source>
        <translation type="obsolete">预览上一级文档/目录（&amp;a）</translation>
    </message>
    <message>
        <source>&amp;Open Parent document/folder</source>
        <translation type="obsolete">打开上一级文档/目录（&amp;O）</translation>
    </message>
    <message>
        <source>&amp;Save as CSV</source>
        <translation>保存为CSV（&amp;S）</translation>
    </message>
    <message>
        <source>Add &quot;%1&quot; column</source>
        <translation>添加&quot;%1&quot;列</translation>
    </message>
    <message>
        <source>Result Table</source>
        <translation>结果表</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">打开</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <source>Open current result document</source>
        <translation>打开当前结果文档</translation>
    </message>
    <message>
        <source>Open current result and quit</source>
        <translation>打开当前结果并退出</translation>
    </message>
    <message>
        <source>Show snippets</source>
        <translation>显示片段</translation>
    </message>
    <message>
        <source>Show header</source>
        <translation>显示标题</translation>
    </message>
    <message>
        <source>Show vertical header</source>
        <translation>显示垂直标题</translation>
    </message>
    <message>
        <source>Copy current result text to clipboard</source>
        <translation>将当前结果文本复制到剪贴板</translation>
    </message>
    <message>
        <source>Use Shift+click to display the text instead.</source>
        <translation>使用Shift+点击来显示文本。</translation>
    </message>
    <message>
        <source>%1 bytes copied to clipboard</source>
        <translation>已复制%1字节到剪贴板</translation>
    </message>
    <message>
        <source>Copy result text and quit</source>
        <translation>复制结果文本并退出</translation>
    </message>
</context>
<context>
    <name>ResTableDetailArea</name>
    <message>
        <source>&amp;Preview</source>
        <translation type="obsolete">预览（&amp;P）</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="obsolete">打开（&amp;O）</translation>
    </message>
    <message>
        <source>Copy &amp;File Name</source>
        <translation type="obsolete">复制文件名（&amp;F）</translation>
    </message>
    <message>
        <source>Copy &amp;URL</source>
        <translation type="obsolete">复制路径（&amp;U）</translation>
    </message>
    <message>
        <source>&amp;Write to File</source>
        <translation type="obsolete">写入文件（&amp;W）</translation>
    </message>
    <message>
        <source>Find &amp;similar documents</source>
        <translation type="obsolete">查找类似的文档（&amp;s）</translation>
    </message>
    <message>
        <source>Preview P&amp;arent document/folder</source>
        <translation type="obsolete">预览上一级文档/目录（&amp;a）</translation>
    </message>
    <message>
        <source>&amp;Open Parent document/folder</source>
        <translation type="obsolete">打开上一级文档/目录（&amp;O）</translation>
    </message>
</context>
<context>
    <name>ResultPopup</name>
    <message>
        <source>&amp;Preview</source>
        <translation type="obsolete">预览（&amp;P）</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation type="obsolete">打开（&amp;O）</translation>
    </message>
    <message>
        <source>Copy &amp;File Name</source>
        <translation type="obsolete">复制文件名（&amp;F）</translation>
    </message>
    <message>
        <source>Copy &amp;URL</source>
        <translation type="obsolete">复制路径（&amp;U）</translation>
    </message>
    <message>
        <source>&amp;Write to File</source>
        <translation type="obsolete">写入文件（&amp;W）</translation>
    </message>
    <message>
        <source>Preview P&amp;arent document/folder</source>
        <translation type="obsolete">预览上一级文档/目录（&amp;a）</translation>
    </message>
    <message>
        <source>&amp;Open Parent document/folder</source>
        <translation type="obsolete">打开上一级文档/目录（&amp;O）</translation>
    </message>
    <message>
        <source>Find &amp;similar documents</source>
        <translation type="obsolete">查找类似的文档（&amp;s）</translation>
    </message>
</context>
<context>
    <name>SSearch</name>
    <message>
        <source>Any term</source>
        <translation>任一词语</translation>
    </message>
    <message>
        <source>All terms</source>
        <translation>全部词语</translation>
    </message>
    <message>
        <source>File name</source>
        <translation>文件名</translation>
    </message>
    <message>
        <source>Query language</source>
        <translation>查询语言</translation>
    </message>
    <message>
        <source>Bad query string</source>
        <translation>查询语言格式不正确</translation>
    </message>
    <message>
        <source>Out of memory</source>
        <translation>内存不足</translation>
    </message>
    <message>
        <source>Too many completions</source>
        <translation type="obsolete">有太多与之相关的补全选项啦</translation>
    </message>
    <message>
        <source>Completions</source>
        <translation type="obsolete">补全选项</translation>
    </message>
    <message>
        <source>Select an item:</source>
        <translation type="obsolete">选择一个条目：</translation>
    </message>
    <message>
        <source>Enter query language expression. Cheat sheet:&lt;br&gt;
&lt;i&gt;term1 term2&lt;/i&gt; : &apos;term1&apos; and &apos;term2&apos; in any field.&lt;br&gt;
&lt;i&gt;field:term1&lt;/i&gt; : &apos;term1&apos; in field &apos;field&apos;.&lt;br&gt;
 Standard field names/synonyms:&lt;br&gt;
  title/subject/caption, author/from, recipient/to, filename, ext.&lt;br&gt;
 Pseudo-fields: dir, mime/format, type/rclcat, date.&lt;br&gt;
 Two date interval exemples: 2009-03-01/2009-05-20  2009-03-01/P2M.&lt;br&gt;
&lt;i&gt;term1 term2 OR term3&lt;/i&gt; : term1 AND (term2 OR term3).&lt;br&gt;
  No actual parentheses allowed.&lt;br&gt;
&lt;i&gt;&quot;term1 term2&quot;&lt;/i&gt; : phrase (must occur exactly). Possible modifiers:&lt;br&gt;
&lt;i&gt;&quot;term1 term2&quot;p&lt;/i&gt; : unordered proximity search with default distance.&lt;br&gt;
Use &lt;b&gt;Show Query&lt;/b&gt; link when in doubt about result and see manual (&amp;lt;F1&gt;) for more detail.
</source>
        <translation type="obsolete">&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;
&lt;!DOCTYPE html PUBLIC &quot;-//W3C//DTD XHTML 1.1 plus MathML 2.0//EN&quot; &quot;http://www.w3.org/Math/DTD/mathml2/xhtml-math11-f.dtd&quot;&gt;
&lt;html xmlns=&quot;http://www.w3.org/1999/xhtml&quot;&gt;&lt;!--This file was converted to xhtml by OpenOffice.org - see http://xml.openoffice.org/odf2xhtml for more info.--&gt;&lt;head profile=&quot;http://dublincore.org/documents/dcmi-terms/&quot;&gt;&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;application/xhtml+xml; charset=utf-8&quot;/&gt;&lt;title xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; ns_1:lang=&quot;en-US&quot;&gt;- no title specified&lt;/title&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.title&quot; content=&quot;&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;meta name=&quot;DCTERMS.language&quot; content=&quot;en-US&quot; scheme=&quot;DCTERMS.RFC4646&quot;/&gt;&lt;meta name=&quot;DCTERMS.source&quot; content=&quot;http://xml.openoffice.org/odf2xhtml&quot;/&gt;&lt;meta name=&quot;DCTERMS.issued&quot; content=&quot;2012-03-23T08:43:25&quot; scheme=&quot;DCTERMS.W3CDTF&quot;/&gt;&lt;meta name=&quot;DCTERMS.modified&quot; content=&quot;2012-03-23T09:07:39&quot; scheme=&quot;DCTERMS.W3CDTF&quot;/&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.provenance&quot; content=&quot;&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;meta xmlns:ns_1=&quot;http://www.w3.org/XML/1998/namespace&quot; name=&quot;DCTERMS.subject&quot; content=&quot;,&quot; ns_1:lang=&quot;en-US&quot;/&gt;&lt;link rel=&quot;schema.DC&quot; href=&quot;http://purl.org/dc/elements/1.1/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCTERMS&quot; href=&quot;http://purl.org/dc/terms/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCTYPE&quot; href=&quot;http://purl.org/dc/dcmitype/&quot; hreflang=&quot;en&quot;/&gt;&lt;link rel=&quot;schema.DCAM&quot; href=&quot;http://purl.org/dc/dcam/&quot; hreflang=&quot;en&quot;/&gt;&lt;style type=&quot;text/css&quot;&gt;
	@page {  }
	table { border-collapse:collapse; border-spacing:0; empty-cells:show }
	td, th { vertical-align:top; font-size:12pt;}
	h1, h2, h3, h4, h5, h6 { clear:both }
	ol, ul { margin:0; padding:0;}
	li { list-style: none; margin:0; padding:0;}
	&lt;!-- &quot;li span.odfLiEnd&quot; - IE 7 issue--&gt;
	li span. { clear: both; line-height:0; width:0; height:0; margin:0; padding:0; }
	span.footnodeNumber { padding-right:1em; }
	span.annotation_style_by_filter { font-size:95%; font-family:Arial; background-color:#fff000;  margin:0; border:0; padding:0;  }
	* { margin:0;}
	.Standard { font-size:12pt; font-family:Nimbus Roman No9 L; writing-mode:page; }
	.T1 { font-style:italic; }
	.T2 { font-style:italic; }
	.T4 { font-weight:bold; }
	&lt;!-- ODF styles with no properties representable as CSS --&gt;
	{ }
	&lt;/style&gt;&lt;/head&gt;&lt;body dir=&quot;ltr&quot; style=&quot;max-width:21.001cm;margin-top:2cm; margin-bottom:2cm; margin-left:2cm; margin-right:2cm; writing-mode:lr-tb; &quot;&gt;&lt;p class=&quot;Standard&quot;&gt;输入查询语言表达式。简要说明：&lt;br/&gt;&lt;span class=&quot;T2&quot;&gt;词语&lt;/span&gt;&lt;span class=&quot;T1&quot;&gt;1 &lt;/span&gt;&lt;span class=&quot;T2&quot;&gt;词语&lt;/span&gt;&lt;span class=&quot;T1&quot;&gt;2&lt;/span&gt; : &apos;词语1&apos;和&apos;词语2&apos;同时出现在任意字段中。&lt;br/&gt;&lt;span class=&quot;T2&quot;&gt;字段&lt;/span&gt;&lt;span class=&quot;T1&quot;&gt;:&lt;/span&gt;&lt;span class=&quot;T2&quot;&gt;词语&lt;/span&gt;&lt;span class=&quot;T1&quot;&gt;1&lt;/span&gt; : &apos;词语1&apos;出现在字段&apos;字段&apos;中。&lt;br/&gt;标准字段名/同义名：&lt;br/&gt;title/subject/caption、author/from、recipient/to、filename、ext。&lt;br/&gt;伪字段名：dir、mime/format、type/rclcat、date。&lt;br/&gt;日期段的两个示例：2009-03-01/2009-05-20 2009-03-01/P2M。&lt;br/&gt;&lt;span class=&quot;T2&quot;&gt;词语&lt;/span&gt;&lt;span class=&quot;T1&quot;&gt;1 &lt;/span&gt;&lt;span class=&quot;T2&quot;&gt;词语&lt;/span&gt;&lt;span class=&quot;T1&quot;&gt;2 OR &lt;/span&gt;&lt;span class=&quot;T2&quot;&gt;词语&lt;/span&gt;&lt;span class=&quot;T1&quot;&gt;3&lt;/span&gt; : 词语1 &lt;span class=&quot;T4&quot;&gt;与&lt;/span&gt; (词语2 &lt;span class=&quot;T4&quot;&gt;或&lt;/span&gt; 词语3)。&lt;br/&gt;不允许用真正的括号来表示逻辑关系。&lt;br/&gt;&lt;span class=&quot;T1&quot;&gt;&quot;&lt;/span&gt;&lt;span class=&quot;T2&quot;&gt;词语&lt;/span&gt;&lt;span class=&quot;T1&quot;&gt;1 &lt;/span&gt;&lt;span class=&quot;T2&quot;&gt;词语&lt;/span&gt;&lt;span class=&quot;T1&quot;&gt;2&quot;&lt;/span&gt; : 词组（必须按原样出现）。可用的修饰词：&lt;br/&gt;&lt;span class=&quot;T1&quot;&gt;&quot;&lt;/span&gt;&lt;span class=&quot;T2&quot;&gt;词语&lt;/span&gt;&lt;span class=&quot;T1&quot;&gt;1 &lt;/span&gt;&lt;span class=&quot;T2&quot;&gt;词语&lt;/span&gt;&lt;span class=&quot;T1&quot;&gt;2&quot;p&lt;/span&gt; : 以默认距离进行的无序近似搜索。&lt;br/&gt;有疑问时可使用&lt;span class=&quot;T4&quot;&gt;显示查询语句细节&lt;/span&gt;链接来查看查询语句的细节，另外请查看手册（&amp;lt;F1&amp;gt;）以了解更多内容。&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</translation>
    </message>
    <message>
        <source>Enter file name wildcard expression.</source>
        <translation>输入文件名通配符表达式。</translation>
    </message>
    <message>
        <source>Enter search terms here. Type ESC SPC for completions of current term.</source>
        <translation type="vanished">在此输入要搜索的词语。按Esc 空格来查看针对当前词语的补全选项。</translation>
    </message>
    <message>
        <source>Stemming languages for stored query: </source>
        <translation>为存储的查询提取语言:</translation>
    </message>
    <message>
        <source>differ from current preferences (kept)</source>
        <translation type="obsolete">与当前偏好不同（保留）</translation>
    </message>
    <message>
        <source>Auto suffixes for stored query: </source>
        <translation>存储查询的自动后缀:</translation>
    </message>
    <message>
        <source>Autophrase is set but it was unset for stored query</source>
        <translation>自动短语已设置，但对于存储的查询已取消设置</translation>
    </message>
    <message>
        <source>Autophrase is unset but it was set for stored query</source>
        <translation>自动短语未设置，但已为存储查询设置。</translation>
    </message>
    <message>
        <source>Enter search terms here.</source>
        <translation>在这里输入搜索词。</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;style&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;style&gt;在文本搜索GUI的上下文中，将以下文本片段从英语翻译成中文。 Text fragment: &lt;html&gt;&lt;head&gt;&lt;style&gt;</translation>
    </message>
    <message>
        <source>table, th, td {</source>
        <translation>表格，th，td {</translation>
    </message>
    <message>
        <source>border: 1px solid black;</source>
        <translation>边框：1像素实线黑色；</translation>
    </message>
    <message>
        <source>border-collapse: collapse;</source>
        <translation>边框折叠：折叠；</translation>
    </message>
    <message>
        <source>}</source>
        <translation>文本片段：}</translation>
    </message>
    <message>
        <source>th,td {</source>
        <translation>th,td { 

th,td {</translation>
    </message>
    <message>
        <source>text-align: center;</source>
        <translation>文本对齐：居中；</translation>
    </message>
    <message>
        <source>&lt;/style&gt;&lt;/head&gt;&lt;body&gt;</source>
        <translation>&lt;/style&gt;&lt;/head&gt;&lt;body&gt; 

&lt;/style&gt;&lt;/head&gt;&lt;body&gt;</translation>
    </message>
    <message>
        <source>You should really look at the manual (F1)&lt;/p&gt;</source>
        <translation>你真的应该查看手册（F1）</translation>
    </message>
    <message>
        <source>&lt;table border=&apos;1&apos; cellspacing=&apos;0&apos;&gt;</source>
        <translation>&lt;table border=&apos;1&apos; cellspacing=&apos;0&apos;&gt; -&gt; &lt;表 border=&apos;1&apos; cellspacing=&apos;0&apos;&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;th&gt;What&lt;/th&gt;&lt;th&gt;Examples&lt;/th&gt;</source>
        <translation>&lt;tr&gt;&lt;th&gt;什么&lt;/th&gt;&lt;th&gt;示例&lt;/th&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;And&lt;/td&gt;&lt;td&gt;one two&amp;nbsp;&amp;nbsp;&amp;nbsp;one AND two&amp;nbsp;&amp;nbsp;&amp;nbsp;one &amp;&amp; two&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;和&lt;/td&gt;&lt;td&gt;一个 两个&amp;nbsp;&amp;nbsp;&amp;nbsp;一个 AND 两个&amp;nbsp;&amp;nbsp;&amp;nbsp;一个 &amp;&amp; 两个&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Or&lt;/td&gt;&lt;td&gt;one OR two&amp;nbsp;&amp;nbsp;&amp;nbsp;one || two&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;或&lt;/td&gt;&lt;td&gt;one OR two&amp;nbsp;&amp;nbsp;&amp;nbsp;one || two&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Complex boolean. OR has priority, use parentheses&amp;nbsp;</source>
        <translation>&lt;tr&gt;&lt;td&gt;复杂布尔。OR 优先级高，使用括号</translation>
    </message>
    <message>
        <source>where needed&lt;/td&gt;&lt;td&gt;(one AND two) OR three&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>在需要的地方&lt;/td&gt;&lt;td&gt;(one AND two) OR three&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Not&lt;/td&gt;&lt;td&gt;-term&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;不&lt;/td&gt;&lt;td&gt;-term&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Phrase&lt;/td&gt;&lt;td&gt;&quot;pride and prejudice&quot;&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;短语&lt;/td&gt;&lt;td&gt;&quot;傲慢与偏见&quot;&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Ordered proximity (slack=1)&lt;/td&gt;&lt;td&gt;&quot;pride prejudice&quot;o1&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;有序接近（松弛=1）&lt;/td&gt;&lt;td&gt;&quot;傲慢与偏见&quot;o1&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Unordered proximity (slack=1)&lt;/td&gt;&lt;td&gt;&quot;prejudice pride&quot;po1&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;无序接近（松弛=1）&lt;/td&gt;&lt;td&gt;“偏见骄傲”po1&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Unordered prox. (default slack=10)&lt;/td&gt;&lt;td&gt;&quot;prejudice&amp;nbsp;pride&quot;p&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;无序近似（默认松弛=10）&lt;/td&gt;&lt;td&gt;&quot;偏见 骄傲&quot;p&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Field-specific&lt;/td&gt;&lt;td&gt;author:austen&amp;nbsp;&amp;nbsp;title:prejudice&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;字段特定&lt;/td&gt;&lt;td&gt;作者：奥斯汀&amp;nbsp;&amp;nbsp;标题：偏见&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;AND inside field (no order)&lt;/td&gt;&lt;td&gt;author:jane,austen&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;字段内AND（无顺序）&lt;/td&gt;&lt;td&gt;作者：简·奥斯汀&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;OR inside field&lt;/td&gt;&lt;td&gt;author:austen/bronte&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;字段内的OR&lt;/td&gt;&lt;td&gt;作者：奥斯汀/勃朗特&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Field names&lt;/td&gt;&lt;td&gt;title/subject/caption&amp;nbsp;&amp;nbsp;author/from&lt;br&gt;recipient/to&amp;nbsp;&amp;nbsp;filename&amp;nbsp;&amp;nbsp;ext&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;字段名称&lt;/td&gt;&lt;td&gt;标题/主题/说明 作者/发件人 收件人/收件人 文件名 扩展名&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Directory path filter&lt;/td&gt;&lt;td&gt;dir:/home/me&amp;nbsp;&amp;nbsp;dir:doc&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;目录路径过滤器&lt;/td&gt;&lt;td&gt;dir:/home/me&amp;nbsp;&amp;nbsp;dir:doc&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;MIME type filter&lt;/td&gt;&lt;td&gt;mime:text/plain mime:video/*&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt; MIME 类型过滤器 &lt;/td&gt; &lt;td&gt; mime:text/plain mime:video/* &lt;/td&gt; &lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Date intervals&lt;/td&gt;&lt;td&gt;date:2018-01-01/2018-31-12&lt;br&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;日期间隔&lt;/td&gt;&lt;td&gt;日期：2018-01-01/2018-31-12&lt;br&gt;</translation>
    </message>
    <message>
        <source>date:2018&amp;nbsp;&amp;nbsp;date:2018-01-01/P12M&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>日期：2018 日期：2018年01月01日/P12M&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Size&lt;/td&gt;&lt;td&gt;size&amp;gt;100k size&amp;lt;1M&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;大小&lt;/td&gt;&lt;td&gt;大小&amp;gt;100k 大小&amp;lt;1M&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source>&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;的中文翻译是：&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Can&apos;t open index</source>
        <translation>无法打开索引</translation>
    </message>
    <message>
        <source>Could not restore external indexes for stored query:&lt;br&gt; </source>
        <translation>无法恢复存储查询的外部索引：&lt;br&gt;</translation>
    </message>
    <message>
        <source>???</source>
        <translation>搜索结果</translation>
    </message>
    <message>
        <source>Using current preferences.</source>
        <translation>使用当前偏好。</translation>
    </message>
    <message>
        <source>Simple search</source>
        <translation>简单搜索</translation>
    </message>
    <message>
        <source>History</source>
        <translation>历史</translation>
    </message>
    <message>
        <source>&lt;p&gt;Query language cheat-sheet. In doubt: click &lt;b&gt;Show Query Details&lt;/b&gt;.&amp;nbsp;</source>
        <translation>查询语言备忘单。有疑问：点击&lt;b&gt;显示查询详情&lt;/b&gt;。</translation>
    </message>
    <message>
        <source>&lt;tr&gt;&lt;td&gt;Capitalize to suppress stem expansion&lt;/td&gt;&lt;td&gt;Floor&lt;/td&gt;&lt;/tr&gt;</source>
        <translation>&lt;tr&gt;&lt;td&gt;大写以抑制词干扩展&lt;/td&gt;&lt;td&gt;地板&lt;/td&gt;&lt;/tr&gt;</translation>
    </message>
    <message>
        <source> differ from current preferences (kept)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Semantic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SSearchBase</name>
    <message>
        <source>SSearchBase</source>
        <translation>SSearchBase</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation type="vanished">Ctrl+S</translation>
    </message>
    <message>
        <source>Erase search entry</source>
        <translation>删除搜索条目</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <source>Start query</source>
        <translation>开始查询</translation>
    </message>
    <message>
        <source>Enter search terms here. Type ESC SPC for completions of current term.</source>
        <translation type="vanished">在此输入要搜索的词语。按Esc 空格来查看针对当前词语的补全选项。</translation>
    </message>
    <message>
        <source>Choose search type.</source>
        <translation>选择搜索类型。</translation>
    </message>
    <message>
        <source>Show query history</source>
        <translation>显示查询历史</translation>
    </message>
    <message>
        <source>Main menu</source>
        <translation>主菜单</translation>
    </message>
</context>
<context>
    <name>SearchClauseW</name>
    <message>
        <source>Select the type of query that will be performed with the words</source>
        <translation>选择要对右边的词语进行的查询类型</translation>
    </message>
    <message>
        <source>Number of additional words that may be interspersed with the chosen ones</source>
        <translation>允许在选中的词语之间出现的额外词语的个数</translation>
    </message>
    <message>
        <source>No field</source>
        <translation>不限字段</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>任意</translation>
    </message>
    <message>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>Phrase</source>
        <translation>词组</translation>
    </message>
    <message>
        <source>Proximity</source>
        <translation>近似</translation>
    </message>
    <message>
        <source>File name</source>
        <translation>文件名</translation>
    </message>
</context>
<context>
    <name>Snippets</name>
    <message>
        <source>Snippets</source>
        <translation>片段</translation>
    </message>
    <message>
        <source>Find:</source>
        <translation>查找：</translation>
    </message>
    <message>
        <source>Next</source>
        <translation>下一页</translation>
    </message>
    <message>
        <source>Prev</source>
        <translation>上一页</translation>
    </message>
</context>
<context>
    <name>SnippetsW</name>
    <message>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <source>&lt;p&gt;Sorry, no exact match was found within limits. Probably the document is very big and the snippets generator got lost in a maze...&lt;/p&gt;</source>
        <translation>抱歉，未在限制范围内找到精确匹配。可能是因为文档太大，片段生成器迷失在迷宫中...</translation>
    </message>
    <message>
        <source>Sort By Relevance</source>
        <translation>按相关性排序</translation>
    </message>
    <message>
        <source>Sort By Page</source>
        <translation>按页面排序</translation>
    </message>
    <message>
        <source>Snippets Window</source>
        <translation>片段窗口</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>查找</translation>
    </message>
    <message>
        <source>Find (alt)</source>
        <translation>查找 (alt)</translation>
    </message>
    <message>
        <source>Find next</source>
        <translation>查找下一个</translation>
    </message>
    <message>
        <source>Find previous</source>
        <translation>查找上一个</translation>
    </message>
    <message>
        <source>Close window</source>
        <translation>关闭窗口</translation>
    </message>
    <message>
        <source>Increase font size</source>
        <translation>增加字体大小</translation>
    </message>
    <message>
        <source>Decrease font size</source>
        <translation>减小字体大小</translation>
    </message>
</context>
<context>
    <name>SpecIdxW</name>
    <message>
        <source>Special Indexing</source>
        <translation>特殊索引</translation>
    </message>
    <message>
        <source>Else only modified or failed files will be processed.</source>
        <translation>否则，只有修改过或失败的文件将被处理。</translation>
    </message>
    <message>
        <source>Erase selected files data before indexing.</source>
        <translation>在索引之前擦除所选文件的数据。</translation>
    </message>
    <message>
        <source>Directory to recursively index. This must be inside the regular indexed area&lt;br&gt; as defined in the configuration file (topdirs).</source>
        <translation>递归索引的目录。这必须在配置文件（topdirs）中定义的常规索引区域内。</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <source>Leave empty to select all files. You can use multiple space-separated shell-type patterns.&lt;br&gt;Patterns with embedded spaces should be quoted with double quotes.&lt;br&gt;Can only be used if the start target is set.</source>
        <translation>留空以选择所有文件。您可以使用多个以空格分隔的shell类型模式。&lt;br&gt;带有嵌入空格的模式应该用双引号引起来。&lt;br&gt;只能在设置了起始目标时使用。</translation>
    </message>
    <message>
        <source>Selection patterns:</source>
        <translation>选择模式:</translation>
    </message>
    <message>
        <source>Top indexed entity</source>
        <translation>顶部索引实体</translation>
    </message>
    <message>
        <source>Retry previously failed files.</source>
        <translation>重试先前失败的文件。</translation>
    </message>
    <message>
        <source>Start directory. Must be part of the indexed tree. Use full indexed area if empty.</source>
        <translation>起始目录。必须是索引树的一部分。如果为空，请使用完整的索引区域。</translation>
    </message>
    <message>
        <source>Diagnostics output file. Will be truncated and receive indexing diagnostics (reasons for files not being indexed).</source>
        <translation>诊断输出文件。将被截断并接收索引诊断（文件未被索引的原因）。</translation>
    </message>
    <message>
        <source>Diagnostics file</source>
        <translation>诊断文件</translation>
    </message>
</context>
<context>
    <name>SpellBase</name>
    <message>
        <source>Term Explorer</source>
        <translation>词语探索器</translation>
    </message>
    <message>
        <source>&amp;Expand </source>
        <translation>展开（&amp;E）</translation>
    </message>
    <message>
        <source>Alt+E</source>
        <translation>Alt+E</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>关闭（&amp;C）</translation>
    </message>
    <message>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <source>No db info.</source>
        <translation>未找到数据库信息。</translation>
    </message>
    <message>
        <source>Match</source>
        <translation>匹配</translation>
    </message>
    <message>
        <source>Case</source>
        <translation>案例</translation>
    </message>
    <message>
        <source>Accents</source>
        <translation>口音</translation>
    </message>
</context>
<context>
    <name>SpellW</name>
    <message>
        <source>Wildcards</source>
        <translation>通配符</translation>
    </message>
    <message>
        <source>Regexp</source>
        <translation>正则表达式</translation>
    </message>
    <message>
        <source>Stem expansion</source>
        <translation>词根扩展</translation>
    </message>
    <message>
        <source>Spelling/Phonetic</source>
        <translation>拼写/发音检查</translation>
    </message>
    <message>
        <source>error retrieving stemming languages</source>
        <translation>提取词根语言时出错</translation>
    </message>
    <message>
        <source>Aspell init failed. Aspell not installed?</source>
        <translation type="vanished">Aspell初始化失败。是否未安装Aspell？</translation>
    </message>
    <message>
        <source>Aspell expansion error. </source>
        <translation type="vanished">Aspell扩展出错。</translation>
    </message>
    <message>
        <source>No expansion found</source>
        <translation>未找到扩展</translation>
    </message>
    <message>
        <source>Term</source>
        <translation>词语</translation>
    </message>
    <message>
        <source>Doc. / Tot.</source>
        <translation>文档数/总数</translation>
    </message>
    <message>
        <source>Index: %1 documents, average length %2 terms</source>
        <translation type="obsolete">索引：%1个文档，平均长度为%2个词语</translation>
    </message>
    <message>
        <source>Index: %1 documents, average length %2 terms.%3 results</source>
        <translation>索引：%1 个文档，平均长度 %2 个词。%3 结果</translation>
    </message>
    <message>
        <source>%1 results</source>
        <translation>%1 个结果</translation>
    </message>
    <message>
        <source>List was truncated alphabetically, some frequent </source>
        <translation>列表按字母顺序截断，一些常见</translation>
    </message>
    <message>
        <source>terms may be missing. Try using a longer root.</source>
        <translation>术语可能缺失。尝试使用更长的根词。</translation>
    </message>
    <message>
        <source>Show index statistics</source>
        <translation>显示索引统计</translation>
    </message>
    <message>
        <source>Number of documents</source>
        <translation>文档数量</translation>
    </message>
    <message>
        <source>Average terms per document</source>
        <translation>每个文档的平均术语</translation>
    </message>
    <message>
        <source>Database directory size</source>
        <translation>数据库目录大小</translation>
    </message>
    <message>
        <source>MIME types:</source>
        <translation>MIME 类型:</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>项目</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>数值</translation>
    </message>
    <message>
        <source>Smallest document length (terms)</source>
        <translation>最小文档长度（术语）</translation>
    </message>
    <message>
        <source>Longest document length (terms)</source>
        <translation>最长文档长度（术语）</translation>
    </message>
    <message>
        <source>Results from last indexing:</source>
        <translation>上次索引的结果:</translation>
    </message>
    <message>
        <source>Documents created/updated</source>
        <translation type="obsolete">文档创建/更新</translation>
    </message>
    <message>
        <source>Files tested</source>
        <translation type="obsolete">文件已测试</translation>
    </message>
    <message>
        <source>Unindexed files</source>
        <translation type="obsolete">未索引的文件</translation>
    </message>
    <message>
        <source>List files which could not be indexed (slow)</source>
        <translation>列出无法被索引的文件（较慢）</translation>
    </message>
    <message>
        <source>Spell expansion error.</source>
        <translation>拼写扩展错误。</translation>
    </message>
    <message>
        <source>  Documents created/updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>  Files tested</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>  Unindexed files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UIPrefsDialog</name>
    <message>
        <source>error retrieving stemming languages</source>
        <translation>提取词根语言时出错</translation>
    </message>
    <message>
        <source>The selected directory does not appear to be a Xapian index</source>
        <translation>选中的目录不是Xapian索引</translation>
    </message>
    <message>
        <source>This is the main/local index!</source>
        <translation>这是主要/本地索引！</translation>
    </message>
    <message>
        <source>The selected directory is already in the index list</source>
        <translation>选中的目录已经在索引列表中</translation>
    </message>
    <message>
        <source>Select xapian index directory (ie: /home/buddy/.recoll/xapiandb)</source>
        <translation type="obsolete">选择xapian索引目录（例如：/home/buddy/.recoll/xapiandb）</translation>
    </message>
    <message>
        <source>Choose</source>
        <translation>选择</translation>
    </message>
    <message>
        <source>Result list paragraph format (erase all to reset to default)</source>
        <translation>结果列表段落格式（擦除所有以重置为默认值）</translation>
    </message>
    <message>
        <source>Result list header (default is empty)</source>
        <translation>结果列表标题（默认为空）</translation>
    </message>
    <message>
        <source>Select recoll config directory or xapian index directory (e.g.: /home/me/.recoll or /home/me/.recoll/xapiandb)</source>
        <translation>选择recoll配置目录或xapian索引目录（例如：/home/me/.recoll或/home/me/.recoll/xapiandb）</translation>
    </message>
    <message>
        <source>The selected directory looks like a Recoll configuration directory but the configuration could not be read</source>
        <translation>所选目录看起来像是一个Recoll配置目录，但配置无法读取。</translation>
    </message>
    <message>
        <source>At most one index should be selected</source>
        <translation>最多只能选择一个索引。</translation>
    </message>
    <message>
        <source>Default QtWebkit font</source>
        <translation>默认的QtWebkit字体</translation>
    </message>
    <message>
        <source>Any term</source>
        <translation>任一词语</translation>
    </message>
    <message>
        <source>All terms</source>
        <translation>全部词语</translation>
    </message>
    <message>
        <source>File name</source>
        <translation>文件名</translation>
    </message>
    <message>
        <source>Query language</source>
        <translation>查询语言</translation>
    </message>
    <message>
        <source>Value from previous program exit</source>
        <translation>上次程序退出时的值</translation>
    </message>
    <message>
        <source>Context</source>
        <translation>上下文</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>快捷方式</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <source>Choose QSS File</source>
        <translation>选择QSS文件</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>轻量</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>暗</translation>
    </message>
    <message>
        <source>System</source>
        <translation>系统</translation>
    </message>
    <message>
        <source>Can&apos;t add index with different case/diacritics stripping option.</source>
        <translation>无法使用不同大小写/变音符号剥离选项添加索引。</translation>
    </message>
</context>
<context>
    <name>ViewAction</name>
    <message>
        <source>Changing actions with different current values</source>
        <translation type="obsolete">正在针对不同的当前值而改变动作</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>命令</translation>
    </message>
    <message>
        <source>MIME type</source>
        <translation>文件类型</translation>
    </message>
    <message>
        <source>Desktop Default</source>
        <translation>桌面默认</translation>
    </message>
    <message>
        <source>Changing entries with different current values</source>
        <translation>使用不同当前值更改条目</translation>
    </message>
</context>
<context>
    <name>ViewActionBase</name>
    <message>
        <source>Native Viewers</source>
        <translation>本地查看器</translation>
    </message>
    <message>
        <source>Select one or several file types, then click Change Action to modify the program used to open them</source>
        <translation type="obsolete">选中一个或多个文件类型，然后点击“修改动作”来修改用来打开这些文件的程序</translation>
    </message>
    <message>
        <source>Change Action</source>
        <translation type="obsolete">修改动作</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <source>Select one or several mime types then click &quot;Change Action&quot;&lt;br&gt;You can also close this dialog and check &quot;Use desktop preferences&quot;&lt;br&gt;in the main panel to ignore this list and use your desktop defaults.</source>
        <translation type="obsolete">选中一个或多个文件类型祟点击“修改动作”&lt;br&gt;或者可以关闭这个对话框，而在主面板中选中“使用桌面默认设置”&lt;br&gt;那样就会无视这个列表而使用桌面的默认设置。</translation>
    </message>
    <message>
        <source>Select one or several mime types then use the controls in the bottom frame to change how they are processed.</source>
        <translation>选择一个或多个MIME类型，然后使用底部框架中的控件来更改它们的处理方式。</translation>
    </message>
    <message>
        <source>Use Desktop preferences by default</source>
        <translation>默认使用桌面偏好设置</translation>
    </message>
    <message>
        <source>Select one or several file types, then use the controls in the frame below to change how they are processed</source>
        <translation>选择一个或多个文件类型，然后使用下方框架中的控件来更改它们的处理方式。</translation>
    </message>
    <message>
        <source>Exception to Desktop preferences</source>
        <translation>桌面偏好设置的异常情况</translation>
    </message>
    <message>
        <source>Action (empty -&gt; recoll default)</source>
        <translation>操作（空 -&gt; recoll 默认）</translation>
    </message>
    <message>
        <source>Apply to current selection</source>
        <translation>应用于当前选择</translation>
    </message>
    <message>
        <source>Recoll action:</source>
        <translation>Recoll操作：</translation>
    </message>
    <message>
        <source>current value</source>
        <translation>当前值</translation>
    </message>
    <message>
        <source>Select same</source>
        <translation>选择相同</translation>
    </message>
    <message>
        <source>&lt;b&gt;New Values:&lt;/b&gt;</source>
        <translation>新值：</translation>
    </message>
    <message>
        <source>The value is a command line to be executed. Substitutions: %s: search string; %p: page number; &lt;br&gt;%f: document file name. F1 for more help.</source>
        <translation>该值是要执行的命令行。替换：%s：搜索字符串；%p：页码；&lt;br&gt;%f：文档文件名。按F1获取更多帮助。</translation>
    </message>
</context>
<context>
    <name>Webcache</name>
    <message>
        <source>Webcache editor</source>
        <translation>Webcache编辑器</translation>
    </message>
    <message>
        <source>Search regexp</source>
        <translation>搜索正则表达式</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation>文本标签</translation>
    </message>
</context>
<context>
    <name>WebcacheEdit</name>
    <message>
        <source>Copy URL</source>
        <translation>复制网址</translation>
    </message>
    <message>
        <source>Unknown indexer state. Can&apos;t edit webcache file.</source>
        <translation>未知的索引器状态。无法编辑Web缓存文件。</translation>
    </message>
    <message>
        <source>Indexer is running. Can&apos;t edit webcache file.</source>
        <translation>索引器正在运行。无法编辑网页缓存文件。</translation>
    </message>
    <message>
        <source>Delete selection</source>
        <translation>删除选择</translation>
    </message>
    <message>
        <source>Webcache was modified, you will need to run the indexer after closing this window.</source>
        <translation>Webcache已被修改，您需要在关闭此窗口后运行索引器。</translation>
    </message>
    <message>
        <source>Save to File</source>
        <translation>保存到文件</translation>
    </message>
    <message>
        <source>File creation failed: </source>
        <translation>文件创建失败：</translation>
    </message>
    <message>
        <source>Maximum size %1 (Index config.). Current size %2. Write position %3.</source>
        <translation>最大尺寸 %1（索引配置）。当前尺寸 %2。写入位置 %3。</translation>
    </message>
</context>
<context>
    <name>WebcacheModel</name>
    <message>
        <source>MIME</source>
        <translation>MIME

多用途互联网邮件扩展(MIME)是一种互联网标准，用于在电子邮件中传输多媒体内容。</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>尺寸</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>路径</translation>
    </message>
</context>
<context>
    <name>WinSchedToolW</name>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>Recoll Batch indexing</source>
        <translation>Recoll批量索引</translation>
    </message>
    <message>
        <source>Start Windows Task Scheduler tool</source>
        <translation>启动Windows任务计划程序工具</translation>
    </message>
    <message>
        <source>Configuration not initialized</source>
        <translation>配置未初始化</translation>
    </message>
    <message>
        <source>Could not create batch file</source>
        <translation>无法创建批处理文件</translation>
    </message>
    <message>
        <source>&lt;h3&gt;Recoll indexing batch scheduling&lt;/h3&gt;&lt;p&gt;We use the standard Windows task scheduler for this. The program will be started when you click the button below.&lt;/p&gt;&lt;p&gt;You can use either the full interface (&lt;i&gt;Create task&lt;/i&gt; in the menu on the right), or the simplified &lt;i&gt;Create Basic task&lt;/i&gt; wizard. In both cases Copy/Paste the batch file path listed below as the &lt;i&gt;Action&lt;/i&gt; to be performed.&lt;/p&gt;</source>
        <translation>&lt;h3&gt;Recoll索引批量调度&lt;/h3&gt;&lt;p&gt;我们使用标准的Windows任务计划程序来实现这一功能。当您点击下面的按钮时，程序将启动。&lt;/p&gt;&lt;p&gt;您可以使用完整界面（右侧菜单中的&lt;i&gt;创建任务&lt;/i&gt;），或者简化的&lt;i&gt;创建基本任务&lt;/i&gt;向导。在两种情况下，将下面列出的批处理文件路径复制/粘贴为要执行的&lt;i&gt;操作&lt;/i&gt;。&lt;/p&gt;</translation>
    </message>
    <message>
        <source>Command already started</source>
        <translation>命令已经启动</translation>
    </message>
</context>
<context>
    <name>confgui::ConfBeaglePanelW</name>
    <message>
        <source>Steal Beagle indexing queue</source>
        <translation type="obsolete">窃取Beagle索引队列</translation>
    </message>
    <message>
        <source>Beagle MUST NOT be running. Enables processing the beagle queue to index Firefox web history.&lt;br&gt;(you should also install the Firefox Beagle plugin)</source>
        <translation type="obsolete">不可运行Beagle。启用对beagle队列的处理，以索引火狐网页历史。&lt;br&gt;（你还需要安装火狐Beagle插件）</translation>
    </message>
    <message>
        <source>Entries will be recycled once the size is reached</source>
        <translation type="obsolete">当尺寸达到设定值时，这些条目会被循环使用</translation>
    </message>
    <message>
        <source>Web page store directory name</source>
        <translation type="vanished">网页储存目录名</translation>
    </message>
    <message>
        <source>The name for a directory where to store the copies of visited web pages.&lt;br&gt;A non-absolute path is taken relative to the configuration directory.</source>
        <translation type="vanished">用来储存复制过来的已访问网页的目录名。&lt;br&gt;如果使用相对路径，则会相对于配置目录的路径进行处理。</translation>
    </message>
    <message>
        <source>Max. size for the web store (MB)</source>
        <translation type="vanished">网页存储的最大尺寸（MB）</translation>
    </message>
</context>
<context>
    <name>confgui::ConfIndexW</name>
    <message>
        <source>Can&apos;t write configuration file</source>
        <translation type="vanished">无法写入配置文件</translation>
    </message>
</context>
<context>
    <name>confgui::ConfParamFNW</name>
    <message>
        <source>Choose</source>
        <translation>选择</translation>
    </message>
</context>
<context>
    <name>confgui::ConfParamSLW</name>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>Add entry</source>
        <translation>添加条目</translation>
    </message>
    <message>
        <source>Delete selected entries</source>
        <translation>删除所选条目</translation>
    </message>
    <message>
        <source>~</source>
        <translation>文本片段：~</translation>
    </message>
    <message>
        <source>Edit selected entries</source>
        <translation>编辑所选条目</translation>
    </message>
</context>
<context>
    <name>confgui::ConfSubPanelW</name>
    <message>
        <source>Global</source>
        <translation type="vanished">全局</translation>
    </message>
    <message>
        <source>Max. compressed file size (KB)</source>
        <translation type="vanished">压缩文件最大尺寸（KB）</translation>
    </message>
    <message>
        <source>This value sets a threshold beyond which compressedfiles will not be processed. Set to -1 for no limit, to 0 for no decompression ever.</source>
        <translation type="vanished">尺寸大于这个值的压缩文件不会被处理。设置成-1以表示不加任何限制，设置成0以表示根本不处理压缩文件。</translation>
    </message>
    <message>
        <source>Max. text file size (MB)</source>
        <translation type="vanished">文本文件最大尺寸（MB）</translation>
    </message>
    <message>
        <source>This value sets a threshold beyond which text files will not be processed. Set to -1 for no limit. 
This is for excluding monster log files from the index.</source>
        <translation type="vanished">尺寸大于这个值的文本文件不会被处理。设置成-1以表示不加限制。
其作用是从索引中排除巨型的记录文件。</translation>
    </message>
    <message>
        <source>Text file page size (KB)</source>
        <translation type="vanished">文本文件单页尺寸（KB）</translation>
    </message>
    <message>
        <source>If this value is set (not equal to -1), text files will be split in chunks of this size for indexing.
This will help searching very big text  files (ie: log files).</source>
        <translation type="vanished">如果设置咯这个值（不等于-1），则文本文件会被分割成这么大的块，并且进行索引。
这是用来搜索大型文本文件的（例如记录文件）。</translation>
    </message>
    <message>
        <source>Max. filter exec. time (S)</source>
        <translation type="vanished">过滤器的最长执行时间（S）</translation>
    </message>
    <message>
        <source>External filters working longer than this will be aborted. This is for the rare case (ie: postscript) where a document could cause a filter to loopSet to -1 for no limit.
</source>
        <translation type="obsolete">外部过滤器的执行时间如果超过这个值，则会被强行中断。在罕见的情况下，某些文档（例如postscript）会导致过滤器陷入死循环。设置成-1以表示不加限制。
</translation>
    </message>
</context>
<context>
    <name>confgui::ConfTabsW</name>
    <message>
        <source>Apply</source>
        <translation>申请</translation>
    </message>
</context>
<context>
    <name>confgui::ConfTopPanelW</name>
    <message>
        <source>Top directories</source>
        <translation type="vanished">顶级目录</translation>
    </message>
    <message>
        <source>The list of directories where recursive indexing starts. Default: your home.</source>
        <translation type="vanished">索引从这个列表中的目录开始，递归地进行。默认：你的家目录。</translation>
    </message>
    <message>
        <source>Skipped paths</source>
        <translation type="vanished">略过的路径</translation>
    </message>
    <message>
        <source>These are names of directories which indexing will not enter.&lt;br&gt; May contain wildcards. Must match the paths seen by the indexer (ie: if topdirs includes &apos;/home/me&apos; and &apos;/home&apos; is actually a link to &apos;/usr/home&apos;, a correct skippedPath entry would be &apos;/home/me/tmp*&apos;, not &apos;/usr/home/me/tmp*&apos;)</source>
        <translation type="vanished">索引进程不会进入具有这些名字的目录。&lt;br&gt;可以包含通配符。必须匹配索引进程自身所见到的路径（例如：如果topdirs包含&apos;/home/me&apos;，而实际上&apos;/home&apos;是到&apos;/usr/home&apos;的链接，则正确的skippedPath条目应当是&apos;/home/me/tmp*&apos;，而不是&apos;/usr/home/me/tmp*&apos;）</translation>
    </message>
    <message>
        <source>Stemming languages</source>
        <translation type="vanished">词根语言</translation>
    </message>
    <message>
        <source>The languages for which stemming expansion&lt;br&gt;dictionaries will be built.</source>
        <translation type="vanished">将会针对这些语言&lt;br&gt;构造词根扩展词典。</translation>
    </message>
    <message>
        <source>Log file name</source>
        <translation type="vanished">记录文件名</translation>
    </message>
    <message>
        <source>The file where the messages will be written.&lt;br&gt;Use &apos;stderr&apos; for terminal output</source>
        <translation type="vanished">程序输出的消息会被保存到这个文件。&lt;br&gt;使用&apos;stderr&apos;以表示将消息输出到终端</translation>
    </message>
    <message>
        <source>Log verbosity level</source>
        <translation type="vanished">记录的话痨级别</translation>
    </message>
    <message>
        <source>This value adjusts the amount of messages,&lt;br&gt;from only errors to a lot of debugging data.</source>
        <translation type="vanished">这个值调整的是输出的消息的数量，&lt;br&gt;其级别从仅输出报错信息到输出一大堆调试信息。</translation>
    </message>
    <message>
        <source>Index flush megabytes interval</source>
        <translation type="vanished">刷新索引的间隔，兆字节</translation>
    </message>
    <message>
        <source>This value adjust the amount of data which is indexed between flushes to disk.&lt;br&gt;This helps control the indexer memory usage. Default 10MB </source>
        <translation type="vanished">这个值调整的是，当积累咯多少索引数据时，才将数据刷新到硬盘上去。&lt;br&gt;用来控制索引进程的内存占用情况。默认为10MB</translation>
    </message>
    <message>
        <source>Max disk occupation (%)</source>
        <translation type="vanished">最大硬盘占用率（%）</translation>
    </message>
    <message>
        <source>This is the percentage of disk occupation where indexing will fail and stop (to avoid filling up your disk).&lt;br&gt;0 means no limit (this is the default).</source>
        <translation type="vanished">当硬盘的占用率达到这个数时，索引会失败并且停止（以避免塞满你的硬盘）。&lt;br&gt;设为0则表示不加限制（这是默认值）。</translation>
    </message>
    <message>
        <source>No aspell usage</source>
        <translation type="vanished">不使用aspell</translation>
    </message>
    <message>
        <source>Aspell language</source>
        <translation type="vanished">Aspell语言</translation>
    </message>
    <message>
        <source>The language for the aspell dictionary. This should look like &apos;en&apos; or &apos;fr&apos; ...&lt;br&gt;If this value is not set, the NLS environment will be used to compute it, which usually works.To get an idea of what is installed on your system, type &apos;aspell config&apos; and look for .dat files inside the &apos;data-dir&apos; directory. </source>
        <translation type="obsolete">aspell词典的语言。表示方式是&apos;en&apos;或&apos;fr&apos;……&lt;br&gt;如果不设置这个值，则会使用系统环境中的自然语言设置信息，而那个通常是正确的。要想查看你的系统中安装咯哪些语言的话，就执行&apos;aspell config&apos;，再在&apos;data-dir&apos;目录中找.dat文件。</translation>
    </message>
    <message>
        <source>Database directory name</source>
        <translation type="vanished">数据库目录名</translation>
    </message>
    <message>
        <source>The name for a directory where to store the index&lt;br&gt;A non-absolute path is taken relative to the  configuration directory. The default is &apos;xapiandb&apos;.</source>
        <translation type="obsolete">用来储存索引数据的目录的名字&lt;br&gt;如果使用相对路径，则路径会相对于配置目录进行计算。默认值是&apos;xapiandb&apos;。</translation>
    </message>
    <message>
        <source>Use system&apos;s &apos;file&apos; command</source>
        <translation type="obsolete">使用系统里的&apos;file&apos;命令</translation>
    </message>
    <message>
        <source>Use the system&apos;s &apos;file&apos; command if internal&lt;br&gt;mime type identification fails.</source>
        <translation type="obsolete">当内部的文件类型识别功能失效时&lt;br&gt;使用系统里的&apos;file&apos;命令。</translation>
    </message>
    <message>
        <source>Disables use of aspell to generate spelling approximation in the term explorer tool.&lt;br&gt; Useful if aspell is absent or does not work. </source>
        <translation type="vanished">禁止在词语探索器中使用aspell来生成拼写相近的词语。&lt;br&gt;在没有安装aspell或者它工作不正常时使用这个选项。</translation>
    </message>
</context>
<context>
    <name>uiPrefsDialogBase</name>
    <message>
        <source>User preferences</source>
        <translation type="vanished">用户选项</translation>
    </message>
    <message>
        <source>User interface</source>
        <translation>用户界面</translation>
    </message>
    <message>
        <source>Number of entries in a result page</source>
        <translation>一个结果页面中显示的结果条数</translation>
    </message>
    <message>
        <source>If checked, results with the same content under different names will only be shown once.</source>
        <translation>如果选中这个，则拥有相同文件内容的不同文件名只会显示一个。</translation>
    </message>
    <message>
        <source>Hide duplicate results.</source>
        <translation>隐藏重复结果。</translation>
    </message>
    <message>
        <source>Highlight color for query terms</source>
        <translation type="vanished">查询词语的高亮颜色</translation>
    </message>
    <message>
        <source>Result list font</source>
        <translation>结果列表字体</translation>
    </message>
    <message>
        <source>Opens a dialog to select the result list font</source>
        <translation>打开一个对话框，以选择用于结果列表的字体</translation>
    </message>
    <message>
        <source>Helvetica-10</source>
        <translation>文泉驿微米黑-12</translation>
    </message>
    <message>
        <source>Resets the result list font to the system default</source>
        <translation>将结果列表中的字体重设为系统默认值</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <source>Texts over this size will not be highlighted in preview (too slow).</source>
        <translation>超过这个长度的文本不会在预览窗口里高亮显示（太慢）。</translation>
    </message>
    <message>
        <source>Maximum text size highlighted for preview (megabytes)</source>
        <translation type="vanished">在预览中对其进行高亮显示的最大文本尺寸（兆字节）</translation>
    </message>
    <message>
        <source>Use desktop preferences to choose document editor.</source>
        <translation type="obsolete">使用桌面系统的设置来选择文档编辑器。</translation>
    </message>
    <message>
        <source>Choose editor applications</source>
        <translation>选择编辑器程序</translation>
    </message>
    <message>
        <source>Display category filter as toolbar instead of button panel (needs restart).</source>
        <translation type="obsolete">将文件类型过滤器显示成工具条，而不是按钮面板（需要重启程序）。</translation>
    </message>
    <message>
        <source>Auto-start simple search on whitespace entry.</source>
        <translation type="vanished">输入空格时自动开始进行简单搜索。</translation>
    </message>
    <message>
        <source>Start with advanced search dialog open.</source>
        <translation type="vanished">启动时打开高端搜索对话框。</translation>
    </message>
    <message>
        <source>Remember sort activation state.</source>
        <translation>记住排序状态。</translation>
    </message>
    <message>
        <source>Prefer Html to plain text for preview.</source>
        <translation type="vanished">预览中优先使用Html。</translation>
    </message>
    <message>
        <source>Search parameters</source>
        <translation>搜索参数</translation>
    </message>
    <message>
        <source>Stemming language</source>
        <translation>词根语言</translation>
    </message>
    <message>
        <source>A search for [rolling stones] (2 terms) will be changed to [rolling or stones or (rolling phrase 2 stones)]. 
This should give higher precedence to the results where the search terms appear exactly as entered.</source>
        <translation>对[滚 石] (2个词语)的搜索会变成[滚 or 石 or (滚 2个词语 石)]。
对于那些搜索词语在其中按照原样出现的结果，其优先级会高一些。</translation>
    </message>
    <message>
        <source>Automatically add phrase to simple searches</source>
        <translation>自动将词组添加到简单搜索中</translation>
    </message>
    <message>
        <source>Do we try to build abstracts for result list entries by using the context of query terms ? 
May be slow for big documents.</source>
        <translation>是否要使用查询词语周围的上下文来构造结果列表条目中的摘要？
对于大的文档可能会很慢。</translation>
    </message>
    <message>
        <source>Dynamically build abstracts</source>
        <translation>动态构造摘要</translation>
    </message>
    <message>
        <source>Do we synthetize an abstract even if the document seemed to have one?</source>
        <translation>即使文档本身拥有一个摘要，我们仍然自行合成摘要信息？</translation>
    </message>
    <message>
        <source>Replace abstracts from documents</source>
        <translation>取代文档中自带的摘要</translation>
    </message>
    <message>
        <source>Synthetic abstract size (characters)</source>
        <translation>合成摘要长度（字符个数）</translation>
    </message>
    <message>
        <source>Synthetic abstract context words</source>
        <translation>合成摘要上下文</translation>
    </message>
    <message>
        <source>The words in the list will be automatically turned to ext:xxx clauses in the query language entry.</source>
        <translation>这个列表中的词语会在查询语言输入框里自动变成ext:xxx语句。</translation>
    </message>
    <message>
        <source>Query language magic file name suffixes.</source>
        <translation>查询语言神奇文件名后缀。</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation>启用</translation>
    </message>
    <message>
        <source>External Indexes</source>
        <translation>外部索引</translation>
    </message>
    <message>
        <source>Toggle selected</source>
        <translation>切换选中项</translation>
    </message>
    <message>
        <source>Activate All</source>
        <translation>全部激活</translation>
    </message>
    <message>
        <source>Deactivate All</source>
        <translation>全部禁用</translation>
    </message>
    <message>
        <source>Remove from list. This has no effect on the disk index.</source>
        <translation>从列表中删除。这不会对硬盘上的索引造成损害。</translation>
    </message>
    <message>
        <source>Remove selected</source>
        <translation>删除选中项</translation>
    </message>
    <message>
        <source>Click to add another index directory to the list</source>
        <translation type="obsolete">点击这里，以将另一个索引目录添加到列表中</translation>
    </message>
    <message>
        <source>Add index</source>
        <translation>添加索引</translation>
    </message>
    <message>
        <source>Apply changes</source>
        <translation>使改变生效</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>确定（&amp;O）</translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation>放弃这些改变</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>取消（&amp;C）</translation>
    </message>
    <message>
        <source>Abstract snippet separator</source>
        <translation>摘要中的片段的分隔符</translation>
    </message>
    <message>
        <source>Style sheet</source>
        <translation type="vanished">样式单</translation>
    </message>
    <message>
        <source>Opens a dialog to select the style sheet file</source>
        <translation type="vanished">打开一个对话框，以选择样式单文件</translation>
    </message>
    <message>
        <source>Choose</source>
        <translation>选择</translation>
    </message>
    <message>
        <source>Resets the style sheet to default</source>
        <translation>将样式单重置为默认值</translation>
    </message>
    <message>
        <source>Lines in PRE text are not folded. Using BR loses some indentation.</source>
        <translation type="obsolete">PRE中的文字不会换行。使用BR的话会使一些缩进失效。</translation>
    </message>
    <message>
        <source>Use &lt;PRE&gt; tags instead of &lt;BR&gt;to display plain text as html in preview.</source>
        <translation type="obsolete">在将纯文本显示成html预览的时候，使用&lt;PRE&gt;标签，而不是&lt;BR&gt;标签。</translation>
    </message>
    <message>
        <source>Result List</source>
        <translation>结果列表</translation>
    </message>
    <message>
        <source>Edit result paragraph format string</source>
        <translation>编辑结果段落的格式字符串</translation>
    </message>
    <message>
        <source>Edit result page html header insert</source>
        <translation>编辑结果页面的html头部插入项</translation>
    </message>
    <message>
        <source>Date format (strftime(3))</source>
        <translation>日期格式（strftime(3)）</translation>
    </message>
    <message>
        <source>Frequency percentage threshold over which we do not use terms inside autophrase. 
Frequent terms are a major performance issue with phrases. 
Skipped terms augment the phrase slack, and reduce the autophrase efficiency.
The default value is 2 (percent). </source>
        <translation>这是一个频率阈值，超过这个值的话，我们就不会把词语放到自动词组中。
高频词语是词组中性能问题的主要来源。
略过的词语会增加词组的空缺值，因此会降低自动词组功能的效率。
默认值是2（百分比）。</translation>
    </message>
    <message>
        <source>Autophrase term frequency threshold percentage</source>
        <translation>自动词组频率阈值百分比</translation>
    </message>
    <message>
        <source>Plain text to HTML line style</source>
        <translation>纯文本转换为HTML行样式</translation>
    </message>
    <message>
        <source>Lines in PRE text are not folded. Using BR loses some indentation. PRE + Wrap style may be what you want.</source>
        <translation>在搜索GUI中，PRE文本中的行不会折叠。使用BR会丢失一些缩进。PRE + Wrap样式可能是您想要的。</translation>
    </message>
    <message>
        <source>&lt;BR&gt;</source>
        <translation>&lt;BR&gt;的中文翻译是: 换行</translation>
    </message>
    <message>
        <source>&lt;PRE&gt;</source>
        <translation>文本搜索 GUI&lt;/PRE&gt;</translation>
    </message>
    <message>
        <source>&lt;PRE&gt; + wrap</source>
        <translation>文本片段： &lt;PRE&gt; + wrap

在文本搜索GUI的上下文中，将上述文本片段从英文翻译成中文为：&lt;PRE&gt; + 自动换行</translation>
    </message>
    <message>
        <source>Disable Qt autocompletion in search entry.</source>
        <translation>在搜索输入框中禁用Qt自动完成。</translation>
    </message>
    <message>
        <source>Paths translations</source>
        <translation>路径翻译</translation>
    </message>
    <message>
        <source>Click to add another index directory to the list. You can select either a Recoll configuration directory or a Xapian index.</source>
        <translation>点击以将另一个索引目录添加到列表中。您可以选择Recoll配置目录或Xapian索引。</translation>
    </message>
    <message>
        <source>Snippets window CSS file</source>
        <translation>片段窗口CSS文件</translation>
    </message>
    <message>
        <source>Opens a dialog to select the Snippets window CSS style sheet file</source>
        <translation>打开一个对话框来选择片段窗口的CSS样式表文件。</translation>
    </message>
    <message>
        <source>Resets the Snippets window style</source>
        <translation>重置片段窗口样式</translation>
    </message>
    <message>
        <source>Decide if document filters are shown as radio buttons, toolbar combobox, or menu.</source>
        <translation>决定文档过滤器显示为单选按钮、工具栏组合框还是菜单。</translation>
    </message>
    <message>
        <source>Document filter choice style:</source>
        <translation type="vanished">文档过滤选择样式:</translation>
    </message>
    <message>
        <source>Buttons Panel</source>
        <translation>按钮面板</translation>
    </message>
    <message>
        <source>Toolbar Combobox</source>
        <translation>工具栏组合框</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>菜单</translation>
    </message>
    <message>
        <source>Show system tray icon.</source>
        <translation>显示系统托盘图标。</translation>
    </message>
    <message>
        <source>Close to tray instead of exiting.</source>
        <translation>最小化到托盘而不是退出。</translation>
    </message>
    <message>
        <source>User style to apply to the snippets window.&lt;br&gt; Note: the result page header insert is also included in the snippets window header.</source>
        <translation>用户样式应用于片段窗口。&lt;br&gt;注意：结果页面标题插入也包含在片段窗口标题中。</translation>
    </message>
    <message>
        <source>Synonyms file</source>
        <translation>同义词文件</translation>
    </message>
    <message>
        <source>Show warning when opening temporary file.</source>
        <translation>打开临时文件时显示警告。</translation>
    </message>
    <message>
        <source>Highlight CSS style for query terms</source>
        <translation>查询词的高亮CSS样式</translation>
    </message>
    <message>
        <source>Recoll - User Preferences</source>
        <translation>Recoll - 用户偏好</translation>
    </message>
    <message>
        <source>Set path translations for the selected index or for the main one if no selection exists.</source>
        <translation>为所选索引设置路径翻译，如果没有选择，则为主要索引设置路径翻译。</translation>
    </message>
    <message>
        <source>Activate links in preview.</source>
        <translation>在预览中激活链接。</translation>
    </message>
    <message>
        <source>Make links inside the preview window clickable, and start an external browser when they are clicked.</source>
        <translation>在预览窗口内使链接可点击，并在点击时启动外部浏览器。</translation>
    </message>
    <message>
        <source>Query terms highlighting in results. &lt;br&gt;Maybe try something like &quot;color:red;background:yellow&quot; for something more lively than the default blue...</source>
        <translation>在结果中突出显示查询词。也许尝试类似于“color:red;background:yellow”这样的样式，比默认的蓝色更生动一些...</translation>
    </message>
    <message>
        <source>Start search on completer popup activation.</source>
        <translation>在自动完成弹出窗口激活时开始搜索。</translation>
    </message>
    <message>
        <source>Maximum number of snippets displayed in the snippets window</source>
        <translation>片段窗口中显示的最大片段数</translation>
    </message>
    <message>
        <source>Suppress all beeps.</source>
        <translation>抑制所有蜂鸣声。</translation>
    </message>
    <message>
        <source>Application Qt style sheet</source>
        <translation>应用程序Qt样式表</translation>
    </message>
    <message>
        <source>Limit the size of the search history. Use 0 to disable, -1 for unlimited.</source>
        <translation>限制搜索历史记录的大小。使用0来禁用，-1表示无限制。</translation>
    </message>
    <message>
        <source>Maximum size of search history (0: disable, -1: unlimited):</source>
        <translation>搜索历史记录的最大大小（0：禁用，-1：无限制）：</translation>
    </message>
    <message>
        <source>Generate desktop notifications.</source>
        <translation>生成桌面通知。</translation>
    </message>
    <message>
        <source>Sort snippets by page number (default: by weight).</source>
        <translation>按页面编号排序片段（默认：按权重排序）。</translation>
    </message>
    <message>
        <source>Misc</source>
        <translation>杂项</translation>
    </message>
    <message>
        <source>Display a Snippets link even if the document has no pages (needs restart).</source>
        <translation>即使文档没有页面，也显示片段链接（需要重新启动）。</translation>
    </message>
    <message>
        <source>Maximum text size highlighted for preview (kilobytes)</source>
        <translation>预览中突出显示的最大文本大小（千字节）</translation>
    </message>
    <message>
        <source>Start with simple search mode: </source>
        <translation>从简单搜索模式开始：</translation>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation>快捷方式</translation>
    </message>
    <message>
        <source>Hide result table header.</source>
        <translation>隐藏结果表头。</translation>
    </message>
    <message>
        <source>Show result table row headers.</source>
        <translation>显示结果表格的行标题。</translation>
    </message>
    <message>
        <source>Reset shortcuts defaults</source>
        <translation>重置快捷键默认值</translation>
    </message>
    <message>
        <source>Use F1 to  access the manual</source>
        <translation>使用F1键访问手册</translation>
    </message>
    <message>
        <source>Hide some user interface elements.</source>
        <translation>隐藏一些用户界面元素。</translation>
    </message>
    <message>
        <source>Hide:</source>
        <translation>隐藏：</translation>
    </message>
    <message>
        <source>Toolbars</source>
        <translation>工具栏</translation>
    </message>
    <message>
        <source>Status bar</source>
        <translation>状态栏</translation>
    </message>
    <message>
        <source>Show button instead.</source>
        <translation>显示按钮。</translation>
    </message>
    <message>
        <source>Menu bar</source>
        <translation>菜单栏</translation>
    </message>
    <message>
        <source>Show choice in menu only.</source>
        <translation>只在菜单中显示选择。</translation>
    </message>
    <message>
        <source>Simple search type</source>
        <translation type="vanished">简单搜索类型</translation>
    </message>
    <message>
        <source>Clear/Search buttons</source>
        <translation type="vanished">清除/搜索按钮</translation>
    </message>
    <message>
        <source>Disable the Ctrl+[0-9]/Shift+[a-z] shortcuts for jumping to table rows.</source>
        <translation>禁用 Ctrl+[0-9]/Shift+[a-z] 快捷键以跳转到表格行。</translation>
    </message>
    <message>
        <source>None (default)</source>
        <translation>无（默认）</translation>
    </message>
    <message>
        <source>Choose QSS File</source>
        <translation>选择QSS文件</translation>
    </message>
    <message>
        <source>To display document text instead of metadata in result table detail area, use:</source>
        <translation>在结果表详细区域显示文档文本而不是元数据，请使用：</translation>
    </message>
    <message>
        <source>left mouse click</source>
        <translation>左键单击</translation>
    </message>
    <message>
        <source>Shift+click</source>
        <translation>Shift+click
Shift+点击</translation>
    </message>
    <message>
        <source>Opens a dialog to select the style sheet file.&lt;br&gt;Look at /usr/share/recoll/examples/recoll[-dark].qss for an example.</source>
        <translation>打开一个对话框来选择样式表文件。&lt;br&gt;查看 /usr/share/recoll/examples/recoll[-dark].qss 以获取示例。</translation>
    </message>
    <message>
        <source>Result Table</source>
        <translation>结果表</translation>
    </message>
    <message>
        <source>Do not display metadata when hovering over rows.</source>
        <translation>当鼠标悬停在行上时，请勿显示元数据。</translation>
    </message>
    <message>
        <source>Work around Tamil QTBUG-78923 by inserting space before anchor text</source>
        <translation>通过在锚文本之前插入空格来解决泰米尔语QTBUG-78923。</translation>
    </message>
    <message>
        <source>The bug causes a strange circle characters to be displayed inside highlighted Tamil words. The workaround inserts an additional space character which appears to fix the problem.</source>
        <translation>该错误导致在突出显示的泰米尔语单词内显示奇怪的圆圈字符。解决方法是插入一个额外的空格字符，这似乎可以解决问题。</translation>
    </message>
    <message>
        <source>Depth of side filter directory tree</source>
        <translation>侧边过滤器目录树的深度</translation>
    </message>
    <message>
        <source>Zoom factor for the user interface. Useful if the default is not right for your screen resolution.</source>
        <translation>用户界面的缩放比例。如果默认值不适合您的屏幕分辨率，这将非常有用。</translation>
    </message>
    <message>
        <source>Display scale (default 1.0):</source>
        <translation>显示比例（默认1.0）:</translation>
    </message>
    <message>
        <source>If set, starting a new instance on the same index will raise an existing one.</source>
        <translation>如果设置了，在相同索引上启动一个新实例将会引发现有的实例。</translation>
    </message>
    <message>
        <source>Single application</source>
        <translation>单个应用程序</translation>
    </message>
    <message>
        <source>Set to 0 to disable and speed up startup by avoiding tree computation.</source>
        <translation>设置为0以禁用并加快启动速度，避免树计算。</translation>
    </message>
    <message>
        <source>See Qt QDateTimeEdit documentation. E.g. yyyy-MM-dd. Leave empty to use the default Qt/System format.</source>
        <translation>查看Qt QDateTimeEdit文档。例如，yyyy-MM-dd。留空以使用默认的Qt/System格式。</translation>
    </message>
    <message>
        <source>Side filter dates format (change needs restart)</source>
        <translation>侧边栏筛选日期格式（更改需要重新启动）</translation>
    </message>
    <message>
        <source>The completion only changes the entry when activated.</source>
        <translation>只有在激活时完成才会更改条目。</translation>
    </message>
    <message>
        <source>Completion: no automatic line editing.</source>
        <translation>完成：无自动行编辑。</translation>
    </message>
    <message>
        <source>Maximum number of history entries in completer list</source>
        <translation>自动完成列表中的历史记录条目最大数量</translation>
    </message>
    <message>
        <source>Number of history entries in completer:</source>
        <translation>自动完成器中的历史记录条目数:</translation>
    </message>
    <message>
        <source>Displays the total number of occurences of the term in the index</source>
        <translation>显示索引中术语的总出现次数</translation>
    </message>
    <message>
        <source>Show hit counts in completer popup.</source>
        <translation>在自动完成弹出窗口中显示命中次数。</translation>
    </message>
    <message>
        <source>Color scheme</source>
        <translation>颜色方案</translation>
    </message>
    <message>
        <source>Interface language (needs restart):</source>
        <translation>界面语言（需要重新启动）:</translation>
    </message>
    <message>
        <source>Note: most translations are incomplete. Leave empty to use the system environment.</source>
        <translation>注意：大多数翻译是不完整的。留空以使用系统环境。</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <source>Prefer HTML to plain text for preview.</source>
        <translation>偏好使用HTML而不是纯文本进行预览。</translation>
    </message>
    <message>
        <source>When displaying HTML in dark mode, try to use a dark background (and light color).&lt;br&gt;This conflicts with many documents which will override our light setting with their own CSS (dark) foreground color, resulting in an unreadable document, so it is off by default.</source>
        <translation>在显示暗模式下的HTML时，请尝试使用暗色背景（和浅色文字）。这与许多文档冲突，这些文档将用它们自己的CSS（暗色）前景色覆盖我们的浅色设置，导致文档无法阅读，因此默认情况下关闭。</translation>
    </message>
    <message>
        <source>Use dark background when displaying HTML in dark mode.</source>
        <translation>在暗模式下显示HTML时，请使用深色背景。</translation>
    </message>
    <message>
        <source>Set to 0 to disable details/summary feature</source>
        <translation>设置为0以禁用详细/摘要功能。</translation>
    </message>
    <message>
        <source>Fields display: max field length before using summary:</source>
        <translation>字段显示：在使用摘要之前的最大字段长度:</translation>
    </message>
    <message>
        <source>Number of lines to be shown over a search term found by preview search.</source>
        <translation>在预览搜索中找到的搜索词上方要显示的行数。</translation>
    </message>
    <message>
        <source>Search term line offset:</source>
        <translation>搜索词行偏移量:</translation>
    </message>
    <message>
        <source>Add common spelling approximations for rare terms.</source>
        <translation>为罕见术语添加常见的拼写近似。</translation>
    </message>
    <message>
        <source>Automatic spelling approximation.</source>
        <translation>自动拼写近似。</translation>
    </message>
    <message>
        <source>Max spelling distance</source>
        <translation>最大拼写距离</translation>
    </message>
    <message>
        <source>Wild card characters *?[] will processed as punctuation instead of being expanded</source>
        <translation>通配符字符*?[]将被处理为标点符号，而不是被展开。</translation>
    </message>
    <message>
        <source>Ignore wild card characters in ALL terms and ANY terms modes</source>
        <translation>在“所有术语”和“任意术语”模式下忽略通配符字符</translation>
    </message>
    <message>
        <source>Things we open when starting up.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open at start:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced Search dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query Fragments window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document category choice style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear/Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do not show the File Size tool in the side filters section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Size side filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;em&gt;Also see the &quot;synthetic abstract&quot; parameters in the Search parameters tab</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
