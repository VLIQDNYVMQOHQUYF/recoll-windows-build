<?xml version="1.0"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"
                xmlns:ve="http://schemas.openxmlformats.org/markup-compatibility/2006"
                xmlns:o="urn:schemas-microsoft-com:office:office"
                xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
                xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
                xmlns:v="urn:schemas-microsoft-com:vml"
                xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
                xmlns:w10="urn:schemas-microsoft-com:office:word"
                xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
                xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml">

  <xsl:output omit-xml-declaration="yes"/>

  <xsl:template match="/">
    <div>
      <xsl:for-each select="//w:p"> 
        <p>
          <xsl:for-each select=".//w:t">
            <xsl:choose>
              <xsl:when test="@space">
                <xsl:if test="@space!='preserve'">
                  <xsl:text> </xsl:text>
                </xsl:if>
                <xsl:value-of select="." />
              </xsl:when>
              <xsl:otherwise>
                <xsl:value-of select="." />
              </xsl:otherwise>
            </xsl:choose>
          </xsl:for-each>
        </p>
      </xsl:for-each>
    </div>
  </xsl:template>

</xsl:stylesheet>
